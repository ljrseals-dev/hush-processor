#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include <doctest/doctest.h>
#include "hush/audio/engine.hpp"
#include "hush/dsp/simper_svf.hpp"
#include "hush/dsp/sparsity_declip.hpp"
#include "hush/simd/ops.hpp"
#include <array>
#include <cmath>
#include <limits>
TEST_CASE("SPSC queue preserves FIFO and rejects full queue") { hush::SpscQueue<int,4U> q; CHECK(q.push(1));CHECK(q.push(2));CHECK(q.push(3));CHECK_FALSE(q.push(4));int v=0;CHECK(q.pop(v));CHECK(v==1);CHECK(q.pop(v));CHECK(v==2); }
TEST_CASE("SVF coefficients match specified equations") { hush::SimperSVF f;f.prepare(48000.0);REQUIRE(f.setParameters(1000.0,0.7071067811865476));const double g=std::tan(3.14159265358979323846*1000.0/48000.0),k=1.0/0.7071067811865476,a1=1.0/(1.0+g*(g+k));CHECK(f.coefficientA1()==doctest::Approx(a1));CHECK(f.coefficientA2()==doctest::Approx(g*a1));CHECK(f.coefficientA3()==doctest::Approx(g*g*a1)); }
TEST_CASE("SIMD gain kernel handles tail and sanitizes") { std::array<float,9> in{},out{};in[0]=1.0F;in[8]=std::numeric_limits<float>::infinity();hush::simd::scalarApplyGain(out.data(),in.data(),out.size(),0.5F);CHECK(out[0]==doctest::Approx(0.5F));CHECK(out[8]==0.0F); }
TEST_CASE("limiter output is bounded") { hush::Limiter l;l.prepare(48000.0);for(int i=0;i<10000;++i)CHECK(std::abs(l.process(i==0?100.0F:0.0F))<=1.0F); }
TEST_CASE("SVF remains finite under impulse") { hush::SimperSVF f;f.prepare(96000.0);std::array<float,512> out{};for(std::size_t i=0U;i<out.size();++i)out[i]=f.process(i==0U?1.0F:0.0F,hush::SVFMode::Lowpass);for(float v:out)CHECK(std::isfinite(v)); }
TEST_CASE("declipper keeps observed samples unchanged") { hush::SparsityDeclipper d;REQUIRE(d.prepare(8U));std::array<float,8>x{0,1,1,0,0,-1,-1,0},y{};std::array<unsigned char,8> m{0,1,1,0,0,1,1,0};CHECK(d.process(x.data(),m.data(),y.data(),x.size()));CHECK(y[0]==x[0]);CHECK(y[3]==x[3]); }
TEST_CASE("engine validates config and bounds output") { hush::Engine e;CHECK(e.prepare({48000.0,128U,2U}));CHECK_FALSE(e.prepare({12345.0,128U,2U}));CHECK(e.prepare({48000.0,128U,2U}));std::array<float,128> l{},r{},in{};in.fill(2.0F);const float* inputs[2]{in.data(),in.data()};e.process(inputs,l.data(),r.data(),128U,1U);for(float v:l)CHECK(std::abs(v)<=1.0F); }
