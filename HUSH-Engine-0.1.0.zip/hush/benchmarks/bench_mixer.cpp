#include "hush/audio/engine.hpp"
#include <array>
#include <chrono>
#include <cstdio>
int main(){hush::Engine engine;if(!engine.prepare({48000.0,512U,2U}))return 1;std::array<float,512> in{},left{},right{};const float* inputs[2]{in.data(),in.data()};const auto start=std::chrono::steady_clock::now();constexpr std::size_t blocks=20000U;for(std::size_t i=0U;i<blocks;++i)engine.process(inputs,left.data(),right.data(),512U,1U);const auto end=std::chrono::steady_clock::now();const double ns=std::chrono::duration<double,std::nano>(end-start).count()/static_cast<double>(blocks);std::printf("HUSH mixer benchmark: %.1f ns/block, %.3f us/block\n",ns,ns/1000.0);return 0;}
