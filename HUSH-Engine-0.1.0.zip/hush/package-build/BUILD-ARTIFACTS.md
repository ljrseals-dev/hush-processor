# HUSH Engine Build Artifacts

Included prebuilt Linux x86-64 artifacts:
- `linux-x86_64/libhush.a` — static HUSH Engine library
- `linux-x86_64/hush_offline_render` — offline-render example executable
- `linux-x86_64/hush_bench` — mixer benchmark executable

These binaries were built in the provided Linux environment. They are not Windows or macOS binaries. Reconfigure and rebuild from the source with CMake on each target platform. The doctest fetch timed out, so this package does not claim a passing unit-test suite.
