#pragma once
#include "hush/audio/track.hpp"
#include "hush/audio/master_bus.hpp"
#include "hush/control/command.hpp"
#include "hush/control/command_queue.hpp"
#include "hush/core/types.hpp"
#include <array>
#include <cstddef>
namespace hush {
class Mixer final {
public:
 bool prepare(AudioConfig config) noexcept;
 bool enqueue(const Command& command) noexcept { return commands_.push(command); }
 Track& track(std::size_t i) noexcept { return tracks_[i < kMaxTracks ? i : 0U]; }
 MasterBus& master() noexcept { return master_; }
 void process(const float* const* inputs,float* outL,float* outR,std::size_t frames,std::size_t activeTracks) noexcept;
private: AudioConfig config_{}; std::array<Track,kMaxTracks> tracks_{}; SpscQueue<Command,kCommandCapacity> commands_{}; MasterBus master_{};
 void applyCommands() noexcept;
};
}
