#pragma once
#include "hush/dsp/smoothing.hpp"
#include <atomic>
#include <cstddef>
namespace hush {
class Track final {
public:
 void prepare(double sampleRate, std::uint32_t rampMs=5U) noexcept;
 void setGain(float gain) noexcept;
 void setPan(float pan) noexcept;
 void setMute(bool v) noexcept { mute_.store(v,std::memory_order_relaxed); }
 void setSolo(bool v) noexcept { solo_.store(v,std::memory_order_relaxed); }
 void setPhaseInvert(bool v) noexcept { phase_.store(v,std::memory_order_relaxed); }
 void setBypass(bool v) noexcept { bypass_.store(v,std::memory_order_relaxed); }
 bool muted() const noexcept { return mute_.load(std::memory_order_relaxed); }
 bool soloed() const noexcept { return solo_.load(std::memory_order_relaxed); }
 void process(const float* inL,const float* inR,float* outL,float* outR,std::size_t frames,bool anySolo) noexcept;
private:
 LinearRamp gain_; double sampleRate_{48000.0}; std::uint32_t rampMs_{5U}; std::atomic<float> gainTarget_{1.0F},pan_{0.0F}; float scheduledGainTarget_{1.0F}; std::atomic<bool> mute_{false},solo_{false},phase_{false},bypass_{false};
};
}
