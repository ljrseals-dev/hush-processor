#pragma once
#include "hush/audio/mixer.hpp"
namespace hush {
class Engine final {
public:
 bool prepare(AudioConfig config) noexcept { return mixer_.prepare(config); }
 Mixer& mixer() noexcept { return mixer_; }
 void process(const float* const* inputs,float* left,float* right,std::size_t frames,std::size_t activeTracks) noexcept { mixer_.process(inputs,left,right,frames,activeTracks); }
private: Mixer mixer_{};
};
}
