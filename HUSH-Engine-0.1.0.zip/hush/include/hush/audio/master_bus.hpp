#pragma once
#include "hush/dsp/limiter.hpp"
#include "hush/core/types.hpp"
#include <atomic>
#include <cstddef>
namespace hush {
class MasterBus final {
public:
 void prepare(double sampleRate) noexcept;
 void setGain(float gain) noexcept { gain_.store(gain,std::memory_order_relaxed); }
 void setMute(bool mute) noexcept { mute_.store(mute,std::memory_order_relaxed); }
 void process(float* left,float* right,std::size_t frames) noexcept;
 Meter meter() const noexcept { return meter_; }
private: std::atomic<float> gain_{1.0F}; std::atomic<bool> mute_{false}; Limiter limiter_; Meter meter_{};
};
}
