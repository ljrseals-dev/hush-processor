#pragma once
#include <cstdint>
namespace hush {
enum class CommandType : std::uint8_t { SetGain, SetPan, SetMute, SetSolo, SetPhase, SetBypass };
struct Command { CommandType type{CommandType::SetGain}; std::uint16_t track{0U}; float value{0.0F}; };
}
