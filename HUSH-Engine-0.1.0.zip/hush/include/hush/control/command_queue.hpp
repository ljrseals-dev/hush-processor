#pragma once
#include <array>
#include <atomic>
#include <cstddef>
#include <type_traits>
namespace hush {
template<class T, std::size_t Capacity> class SpscQueue final {
    static_assert(Capacity >= 2U && (Capacity & (Capacity - 1U)) == 0U);
    static_assert(std::is_trivially_copyable_v<T>);
public:
    bool push(const T& value) noexcept { const auto h = head_.load(std::memory_order_relaxed); const auto next = (h + 1U) & mask; if (next == tail_.load(std::memory_order_acquire)) return false; data_[h] = value; head_.store(next, std::memory_order_release); return true; }
    bool pop(T& value) noexcept { const auto t = tail_.load(std::memory_order_relaxed); if (t == head_.load(std::memory_order_acquire)) return false; value = data_[t]; tail_.store((t + 1U) & mask, std::memory_order_release); return true; }
    static constexpr std::size_t usableCapacity() noexcept { return Capacity - 1U; }
private:
    static constexpr std::size_t mask = Capacity - 1U;
    alignas(64) std::array<T, Capacity> data_{};
    alignas(64) std::atomic<std::size_t> head_{0U};
    alignas(64) std::atomic<std::size_t> tail_{0U};
};
}
