#pragma once
#include <cstdint>
#if defined(__SSE__)
#include <xmmintrin.h>
#endif
#if defined(__aarch64__) && defined(__GNUC__)
#include <arm_neon.h>
#endif
namespace hush {
class ScopedDenormals final {
public:
    ScopedDenormals() noexcept {
#if defined(__SSE__)
        old_ = _mm_getcsr(); _mm_setcsr(old_ | 0x8040U);
#elif defined(__aarch64__) && defined(__GNUC__)
        asm volatile("mrs %0, fpcr" : "=r"(old_)); const std::uint64_t next = old_ | (1ULL << 24U); asm volatile("msr fpcr, %0" :: "r"(next));
#endif
    }
    ~ScopedDenormals() noexcept {
#if defined(__SSE__)
        _mm_setcsr(old_);
#elif defined(__aarch64__) && defined(__GNUC__)
        asm volatile("msr fpcr, %0" :: "r"(old_));
#endif
    }
    ScopedDenormals(const ScopedDenormals&) = delete;
    ScopedDenormals& operator=(const ScopedDenormals&) = delete;
private:
#if defined(__SSE__)
    unsigned int old_{0U};
#elif defined(__aarch64__) && defined(__GNUC__)
    std::uint64_t old_{0U};
#endif
};
}
