#pragma once
#include <algorithm>
#include <cmath>
#include <limits>
namespace hush::rt {
inline float sanitize(float x) noexcept { return std::isfinite(x) ? x : 0.0F; }
inline float clampUnit(float x) noexcept { return std::clamp(sanitize(x), -1.0F, 1.0F); }
inline float finiteClamp(float x, float lo, float hi, float fallback = 0.0F) noexcept { return std::isfinite(x) ? std::clamp(x, lo, hi) : fallback; }
inline float dbToGain(float db) noexcept { return std::pow(10.0F, finiteClamp(db, -160.0F, 24.0F) / 20.0F); }
}
