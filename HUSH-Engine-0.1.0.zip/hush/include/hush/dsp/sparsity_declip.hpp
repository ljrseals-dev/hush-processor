#pragma once
#include <cstddef>
#include <vector>
namespace hush {
struct DeclipConfig { std::size_t iterations{30U}; float threshold{0.02F}; float step{0.8F}; };
class SparsityDeclipper final {
public:
 bool prepare(std::size_t maxFrames);
 bool process(const float* clipped, const unsigned char* clippedMask, float* restored, std::size_t frames, DeclipConfig config={}) noexcept;
private: std::vector<float> work_,gradient_;
};
}
