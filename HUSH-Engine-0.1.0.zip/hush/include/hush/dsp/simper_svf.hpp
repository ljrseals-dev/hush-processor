#pragma once
namespace hush {
enum class SVFMode { Lowpass, Highpass, Bandpass, Notch, Peak, Allpass };
class SimperSVF final {
public:
 void prepare(double sampleRate) noexcept;
 bool setParameters(double cutoff, double q) noexcept;
 void reset() noexcept;
 float process(float input, SVFMode mode) noexcept;
 double coefficientA1() const noexcept { return a1_; }
 double coefficientA2() const noexcept { return a2_; }
 double coefficientA3() const noexcept { return a3_; }
private: double sampleRate_{48000.0}, g_{0.0}, k_{0.7071067811865476}, a1_{1.0},a2_{0.0},a3_{0.0},ic1_{0.0},ic2_{0.0};
};
}
