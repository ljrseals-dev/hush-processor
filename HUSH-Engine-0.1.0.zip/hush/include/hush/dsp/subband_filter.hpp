#pragma once
#include <cstddef>
#include <vector>
namespace hush {
class SubbandFilterBank final {
public:
 bool prepare(std::size_t bands, std::size_t taps);
 void setBandCoefficients(std::size_t band, const float* coefficients, std::size_t count) noexcept;
 void processBand(std::size_t band, const float* input, float* output, std::size_t frames) noexcept;
 std::size_t bands() const noexcept { return bands_; }
 std::size_t decimationFactor() const noexcept { return bands_; }
private: std::size_t bands_{0U},taps_{0U}; std::vector<float> coeffs_,history_; std::vector<std::size_t> cursor_;
};
}
