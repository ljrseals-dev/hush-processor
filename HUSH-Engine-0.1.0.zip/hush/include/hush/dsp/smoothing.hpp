#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
namespace hush {
class LinearRamp final {
public:
 void reset(float value) noexcept { current_=target_=value; step_=0.0F; remaining_=0U; }
 void setTarget(float target, std::uint32_t samples) noexcept { target_=target; if(samples==0U){reset(target);return;} remaining_=samples; step_=(target_-current_)/static_cast<float>(samples); }
 float next() noexcept { if(remaining_>0U){current_+=step_; --remaining_; if(remaining_==0U) current_=target_;} return current_; }
 float current() const noexcept { return current_; }
private: float current_{1.0F},target_{1.0F},step_{0.0F}; std::uint32_t remaining_{0U};
};
}
