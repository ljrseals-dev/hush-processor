#pragma once
#include <cstddef>
#include <cmath>
#include <algorithm>
namespace hush {
class VariableCadenceEngine final {
public:
 void prepare(double sampleRate, float attackMs=5.0F, float releaseMs=80.0F) noexcept;
 template<class Update> void process(const float* envelope, std::size_t count, Update&& update) noexcept {
  std::size_t i=0U; while(i<count){ const float e=envelope[i]; const bool transient=std::abs(e-envelopeState_)>threshold_; if(transient){ envelopeState_=e; update(i); ++i; continue; }
   const std::size_t n=(count-i>=4U)?4U:count-i; float sum=0.0F; for(std::size_t j=0U;j<n;++j)sum+=envelope[i+j]; envelopeState_=sum/static_cast<float>(n); update(i); i+=n;
  }
 }
 void setThreshold(float t) noexcept { threshold_ = t < 0.0F ? 0.0F : t; }
private: float envelopeState_{0.0F},threshold_{0.02F},attackCoeff_{0.0F},releaseCoeff_{0.0F};
};
}
