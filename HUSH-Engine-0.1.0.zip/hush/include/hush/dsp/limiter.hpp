#pragma once
#include <cstdint>
namespace hush {
class Limiter final {
public:
 void prepare(double sampleRate) noexcept;
 void setThreshold(float linear) noexcept;
 float process(float x) noexcept;
 void reset() noexcept;
private: float threshold_{0.8912509F}; float envelope_{0.0F}; float gain_{1.0F}; float attack_{0.0F}; float release_{0.0F}; float knee_{0.1F};
};
}
