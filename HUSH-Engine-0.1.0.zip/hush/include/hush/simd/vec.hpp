#pragma once
#include <array>
#include <cstddef>
namespace hush::simd {
template<std::size_t N> struct F32x { std::array<float, N> lane{}; float& operator[](std::size_t i) noexcept { return lane[i]; } const float& operator[](std::size_t i) const noexcept { return lane[i]; } };
using F32x4 = F32x<4U>; using F32x8 = F32x<8U>;
}
