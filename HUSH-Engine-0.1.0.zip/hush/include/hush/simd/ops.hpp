#pragma once
#include "hush/core/rt_math.hpp"
#include <cstddef>
namespace hush::simd {
using ApplyGainFn = void(*)(float*, const float*, std::size_t, float) noexcept;
using AccumulateFn = void(*)(float*, const float*, const float*, std::size_t, float, float) noexcept;
using ZeroFn = void(*)(float*, std::size_t) noexcept;
void scalarApplyGain(float*, const float*, std::size_t, float) noexcept;
void scalarAccumulateStereo(float*, const float*, const float*, std::size_t, float, float) noexcept;
void scalarZero(float*, std::size_t) noexcept;
void sse2ApplyGain(float*, const float*, std::size_t, float) noexcept;
void avx2ApplyGain(float*, const float*, std::size_t, float) noexcept;
void neonApplyGain(float*, const float*, std::size_t, float) noexcept;
}
