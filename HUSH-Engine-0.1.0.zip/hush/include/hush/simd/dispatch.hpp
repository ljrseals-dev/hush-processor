#pragma once
#include "hush/simd/ops.hpp"
namespace hush::simd {
enum class ISA { Scalar, SSE2, AVX2, NEON };
struct KernelTable { ApplyGainFn applyGain{scalarApplyGain}; AccumulateFn accumulateStereo{scalarAccumulateStereo}; ZeroFn zero{scalarZero}; ISA isa{ISA::Scalar}; };
const KernelTable& kernels() noexcept;
}
