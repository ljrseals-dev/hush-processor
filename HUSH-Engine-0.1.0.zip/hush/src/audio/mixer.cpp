#include "hush/audio/mixer.hpp"
#include "hush/core/denormals.hpp"
#include <algorithm>
namespace hush {
bool Mixer::prepare(AudioConfig c) noexcept { if(!validSampleRate(c.sampleRate)||!validBlockSize(c.maxBlockSize)||c.channels==0U||c.channels>kMaxChannels)return false;config_=c;for(auto& t:tracks_)t.prepare(c.sampleRate);master_.prepare(c.sampleRate);return true; }
void Mixer::applyCommands() noexcept { Command c{};while(commands_.pop(c)){if(c.track>=kMaxTracks)continue;auto& t=tracks_[c.track];switch(c.type){case CommandType::SetGain:t.setGain(c.value);break;case CommandType::SetPan:t.setPan(c.value);break;case CommandType::SetMute:t.setMute(c.value>=0.5F);break;case CommandType::SetSolo:t.setSolo(c.value>=0.5F);break;case CommandType::SetPhase:t.setPhaseInvert(c.value>=0.5F);break;case CommandType::SetBypass:t.setBypass(c.value>=0.5F);break;}} }
void Mixer::process(const float* const* inputs,float* outL,float* outR,std::size_t n,std::size_t active) noexcept { ScopedDenormals denormals; (void)denormals;if(outL==nullptr||outR==nullptr||n>config_.maxBlockSize)return;applyCommands();std::fill_n(outL,n,0.0F);std::fill_n(outR,n,0.0F);active=std::min(active,kMaxTracks);bool anySolo=false;for(std::size_t i=0U;i<active;++i)anySolo=anySolo||tracks_[i].soloed();for(std::size_t t=0U;t<active;++t){const float* inL=(inputs!=nullptr)?inputs[t*2U]:nullptr;const float* inR=(inputs!=nullptr)?inputs[t*2U+1U]:nullptr;float left[2048]{};float right[2048]{};tracks_[t].process(inL,inR,left,right,n,anySolo);for(std::size_t i=0U;i<n;++i){outL[i]+=left[i];outR[i]+=right[i];}}
 master_.process(outL,outR,n); }
}
