#include "hush/audio/track.hpp"
#include "hush/core/rt_math.hpp"
#include <algorithm>
#include <cmath>
namespace hush {
void Track::prepare(double sr,std::uint32_t rampMs) noexcept { sampleRate_=(std::isfinite(sr)&&sr>=8000.0)?sr:48000.0;rampMs_=std::min(rampMs,1000U);scheduledGainTarget_=gainTarget_.load(std::memory_order_relaxed);gain_.reset(scheduledGainTarget_); }
void Track::setGain(float g) noexcept { gainTarget_.store(rt::finiteClamp(g,0.0F,4.0F,1.0F),std::memory_order_relaxed); }
void Track::setPan(float p) noexcept { pan_.store(rt::finiteClamp(p,-1.0F,1.0F,0.0F),std::memory_order_relaxed); }
void Track::process(const float* inL,const float* inR,float* outL,float* outR,std::size_t n,bool anySolo) noexcept { if(outL==nullptr||outR==nullptr)return; const bool silent=mute_.load(std::memory_order_relaxed)||(anySolo&&!solo_.load(std::memory_order_relaxed));const bool phase=phase_.load(std::memory_order_relaxed);const bool bypass=bypass_.load(std::memory_order_relaxed);const float target=gainTarget_.load(std::memory_order_relaxed);const auto rampSamples=static_cast<std::uint32_t>(std::max(1.0, sampleRate_*static_cast<double>(rampMs_)/1000.0));if(std::abs(target-scheduledGainTarget_)>1.0e-6F){gain_.setTarget(target,rampSamples);scheduledGainTarget_=target;}const float pan=pan_.load(std::memory_order_relaxed);const float angle=(pan+1.0F)*0.7853981633974483F;const float lpan=std::cos(angle),rpan=std::sin(angle);const float stereoL=pan<=0.0F?1.0F:std::cos(pan*1.5707963267948966F);const float stereoR=pan>=0.0F?1.0F:std::cos(pan*1.5707963267948966F);
 for(std::size_t i=0U;i<n;++i){float l=(inL!=nullptr)?rt::sanitize(inL[i]):0.0F;float r=(inR!=nullptr)?rt::sanitize(inR[i]):l;if(silent){l=0.0F;r=0.0F;}else if(!bypass){const float g=gain_.next()*(phase?-1.0F:1.0F);l*=g;r*=g;l*=stereoL;r*=stereoR;}else {l*=phase?-1.0F:1.0F;r*=phase?-1.0F:1.0F;}if(!silent&&inR==nullptr){l*=lpan;r=l*rpan;}outL[i]=l;outR[i]=r;}
}
}
