#include "hush/audio/master_bus.hpp"
#include "hush/core/rt_math.hpp"
#include <algorithm>
#include <cmath>
namespace hush {
void MasterBus::prepare(double sr) noexcept { limiter_.prepare(sr);meter_={}; }
void MasterBus::process(float* l,float* r,std::size_t n) noexcept { if(l==nullptr||r==nullptr)return;const float g=rt::finiteClamp(gain_.load(std::memory_order_relaxed),0.0F,4.0F,1.0F);const bool muted=mute_.load(std::memory_order_relaxed);float peak=0.0F;double sum=0.0;for(std::size_t i=0U;i<n;++i){float a=muted?0.0F:rt::sanitize(l[i])*g;float b=muted?0.0F:rt::sanitize(r[i])*g;a=limiter_.process(a);b=limiter_.process(b);l[i]=rt::clampUnit(a);r[i]=rt::clampUnit(b);peak=std::max(peak,std::max(std::abs(l[i]),std::abs(r[i])));sum+=static_cast<double>(l[i])*static_cast<double>(l[i])+static_cast<double>(r[i])*static_cast<double>(r[i]);}meter_.peak=peak;meter_.rms=n>0U?static_cast<float>(std::sqrt(sum/(2.0*static_cast<double>(n)))):0.0F; }
}
