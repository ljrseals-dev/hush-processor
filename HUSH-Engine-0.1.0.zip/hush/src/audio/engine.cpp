#include "hush/audio/engine.hpp"
namespace hush {
// Engine's public operations are thin, inline forwarding methods; this translation unit anchors the library target.
static_assert(kMaxTracks == 64U);
}
