#include "hush/simd/ops.hpp"
#if defined(__ARM_NEON)
#include <arm_neon.h>
#endif
namespace hush::simd {
void neonApplyGain(float* out,const float* in,std::size_t n,float gain) noexcept {
#if defined(__ARM_NEON)
 if(out==nullptr||in==nullptr)return; const float32x4_t g=vdupq_n_f32(rt::sanitize(gain)); std::size_t i=0U; for(;i+4U<=n;i+=4U)vst1q_f32(out+i,vmulq_f32(vld1q_f32(in+i),g)); for(;i<n;++i)out[i]=rt::sanitize(in[i])*gain;
#else
 scalarApplyGain(out,in,n,gain);
#endif
}
}
