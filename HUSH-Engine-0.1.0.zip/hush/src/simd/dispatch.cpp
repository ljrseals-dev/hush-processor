#include "hush/simd/dispatch.hpp"
namespace hush::simd {
const KernelTable& kernels() noexcept { static const KernelTable table = []() noexcept { KernelTable t{};
#if defined(__AVX2__)
 t.applyGain=avx2ApplyGain; t.isa=ISA::AVX2;
#elif defined(__SSE2__)
 t.applyGain=sse2ApplyGain; t.isa=ISA::SSE2;
#elif defined(__ARM_NEON)
 t.applyGain=neonApplyGain; t.isa=ISA::NEON;
#endif
 return t; }(); return table; }
}
