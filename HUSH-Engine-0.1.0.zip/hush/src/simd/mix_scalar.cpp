#include "hush/simd/ops.hpp"
#include <algorithm>
namespace hush::simd {
void scalarApplyGain(float* out,const float* in,std::size_t n,float gain) noexcept { if(out==nullptr||in==nullptr)return; gain=rt::sanitize(gain); for(std::size_t i=0U;i<n;++i)out[i]=rt::sanitize(in[i])*gain; }
void scalarAccumulateStereo(float* outL,const float* inL,const float* inR,std::size_t n,float gainL,float gainR) noexcept { if(outL==nullptr||inL==nullptr||inR==nullptr)return; for(std::size_t i=0U;i<n;++i)outL[i]+=rt::sanitize(inL[i])*gainL+rt::sanitize(inR[i])*gainR; }
void scalarZero(float* out,std::size_t n) noexcept { if(out==nullptr)return; std::fill_n(out,n,0.0F); }
}
