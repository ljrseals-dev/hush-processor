#include "hush/simd/ops.hpp"
#if defined(__SSE2__)
#include <emmintrin.h>
#endif
namespace hush::simd {
void sse2ApplyGain(float* out,const float* in,std::size_t n,float gain) noexcept {
#if defined(__SSE2__)
 if(out==nullptr||in==nullptr)return; const __m128 g=_mm_set1_ps(rt::sanitize(gain)); std::size_t i=0U; for(;i+4U<=n;i+=4U){const __m128 x=_mm_loadu_ps(in+i);_mm_storeu_ps(out+i,_mm_mul_ps(x,g));} for(;i<n;++i)out[i]=rt::sanitize(in[i])*gain;
#else
 scalarApplyGain(out,in,n,gain);
#endif
}
}
