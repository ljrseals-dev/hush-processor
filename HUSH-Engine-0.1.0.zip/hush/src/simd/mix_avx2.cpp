#include "hush/simd/ops.hpp"
#if defined(__AVX2__)
#include <immintrin.h>
#endif
namespace hush::simd {
void avx2ApplyGain(float* out,const float* in,std::size_t n,float gain) noexcept {
#if defined(__AVX2__)
 if(out==nullptr||in==nullptr)return; const __m256 g=_mm256_set1_ps(rt::sanitize(gain)); std::size_t i=0U; for(;i+8U<=n;i+=8U){const __m256 x=_mm256_loadu_ps(in+i);_mm256_storeu_ps(out+i,_mm256_mul_ps(x,g));} for(;i<n;++i)out[i]=rt::sanitize(in[i])*gain;
#else
 scalarApplyGain(out,in,n,gain);
#endif
}
}
