#include "hush/dsp/sparsity_declip.hpp"
#include <algorithm>
#include <cmath>
namespace hush {
bool SparsityDeclipper::prepare(std::size_t n) { if(n==0U||n>1U<<22U)return false;work_.assign(n,0.0F);gradient_.assign(n,0.0F);return true; }
bool SparsityDeclipper::process(const float* x,const unsigned char* mask,float* out,std::size_t n,DeclipConfig cfg) noexcept { if(x==nullptr||mask==nullptr||out==nullptr||n==0U||n>work_.size()||cfg.iterations==0U||!std::isfinite(cfg.step)||cfg.step<=0.0F)return false; cfg.step=std::clamp(cfg.step,0.01F,1.0F);cfg.threshold=std::clamp(cfg.threshold,0.0F,1.0F);for(std::size_t i=0U;i<n;++i)out[i]=std::isfinite(x[i])?x[i]:0.0F;
 // Iterative soft-thresholded second-difference regularization. Observed samples remain fixed;
 // only samples marked as clipped are reconstructed. This is a bounded time-domain sparse prior.
 for(std::size_t it=0U;it<cfg.iterations;++it){for(std::size_t i=0U;i<n;++i){const float left=out[i==0U?0U:i-1U],right=out[i+1U<n?i+1U:n-1U];const float curvature=left-2.0F*out[i]+right;gradient_[i]=curvature;}for(std::size_t i=0U;i<n;++i){if(mask[i]!=0U){const float v=out[i]-cfg.step*gradient_[i];const float a=std::abs(v);out[i]=a<=cfg.threshold?0.0F:std::copysign(a-cfg.threshold,v);}}}
 for(std::size_t i=0U;i<n;++i)if(mask[i]==0U)out[i]=std::isfinite(x[i])?x[i]:0.0F;return true; }
}
