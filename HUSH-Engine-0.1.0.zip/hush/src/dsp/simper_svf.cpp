#include "hush/dsp/simper_svf.hpp"
#include "hush/core/rt_math.hpp"
#include <cmath>
namespace hush {
void SimperSVF::prepare(double sr) noexcept { sampleRate_=(std::isfinite(sr)&&sr>=8000.0)?sr:48000.0; (void)setParameters(1000.0,0.7071067811865476); reset(); }
bool SimperSVF::setParameters(double fc,double q) noexcept { if(!std::isfinite(fc)||!std::isfinite(q)||q<=0.0)return false; fc=std::clamp(fc,1.0,sampleRate_*0.499); q=std::clamp(q,0.05,100.0); g_=std::tan(3.14159265358979323846*fc/sampleRate_); k_=1.0/q; a1_=1.0/(1.0+g_*(g_+k_)); a2_=g_*a1_; a3_=g_*a2_; return std::isfinite(a1_)&&std::isfinite(a2_)&&std::isfinite(a3_); }
void SimperSVF::reset() noexcept { ic1_=0.0; ic2_=0.0; }
float SimperSVF::process(float input,SVFMode mode) noexcept { const double v0=static_cast<double>(rt::sanitize(input)); const double v3=v0-ic2_; const double v1=a1_*ic1_+a2_*v3; const double v2=ic2_+a2_*ic1_+a3_*v3; ic1_=2.0*v1-ic1_; ic2_=2.0*v2-ic2_; const double hp=v0-k_*v1-v2; double y=0.0; switch(mode){case SVFMode::Lowpass:y=v2;break;case SVFMode::Highpass:y=hp;break;case SVFMode::Bandpass:y=v1;break;case SVFMode::Notch:y=hp+v2;break;case SVFMode::Peak:y=hp-v2;break;case SVFMode::Allpass:y=hp+v2-k_*v1;break;} return std::isfinite(y)?static_cast<float>(y):0.0F; }
}
