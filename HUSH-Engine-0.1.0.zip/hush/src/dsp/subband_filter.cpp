#include "hush/dsp/subband_filter.hpp"
#include <algorithm>
#include <cmath>
namespace hush {
bool SubbandFilterBank::prepare(std::size_t bands,std::size_t taps) { if(bands<2U||bands>64U||taps==0U||taps>4096U)return false; bands_=bands;taps_=taps; coeffs_.assign(bands*taps,0.0F);history_.assign(bands*taps,0.0F);cursor_.assign(bands,0U); for(std::size_t b=0U;b<bands_;++b)coeffs_[b*taps_]=1.0F; return true; }
void SubbandFilterBank::setBandCoefficients(std::size_t band,const float* c,std::size_t n) noexcept { if(band>=bands_||c==nullptr||n==0U)return; const auto count=std::min(n,taps_); float sum=0.0F; for(std::size_t i=0U;i<count;++i){const float v=std::isfinite(c[i])?c[i]:0.0F;coeffs_[band*taps_+i]=v;sum+=std::abs(v);} for(std::size_t i=count;i<taps_;++i)coeffs_[band*taps_+i]=0.0F; if(sum>1.0e-12F){for(std::size_t i=0U;i<count;++i)coeffs_[band*taps_+i]/=sum;} }
void SubbandFilterBank::processBand(std::size_t band,const float* in,float* out,std::size_t n) noexcept { if(band>=bands_||in==nullptr||out==nullptr)return; auto* h=history_.data()+band*taps_;const auto* c=coeffs_.data()+band*taps_;std::size_t pos=cursor_[band];for(std::size_t i=0U;i<n;++i){h[pos]=std::isfinite(in[i])?in[i]:0.0F;float y=0.0F;std::size_t p=pos;for(std::size_t k=0U;k<taps_;++k){y+=c[k]*h[p];p=(p==0U)?taps_-1U:p-1U;}out[i]=std::isfinite(y)?y:0.0F;pos=(pos+1U)%taps_;}cursor_[band]=pos; }
}
