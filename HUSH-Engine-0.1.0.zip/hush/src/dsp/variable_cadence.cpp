#include "hush/dsp/variable_cadence.hpp"
#include <cmath>
namespace hush {
void VariableCadenceEngine::prepare(double sr,float attackMs,float releaseMs) noexcept { if(!std::isfinite(sr)||sr<8000.0)sr=48000.0; attackMs=std::clamp(attackMs,0.1F,500.0F); releaseMs=std::clamp(releaseMs,1.0F,2000.0F); attackCoeff_=std::exp(-1.0F/(0.001F*attackMs*static_cast<float>(sr))); releaseCoeff_=std::exp(-1.0F/(0.001F*releaseMs*static_cast<float>(sr))); envelopeState_=0.0F; }
}
