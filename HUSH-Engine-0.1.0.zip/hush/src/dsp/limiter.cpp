#include "hush/dsp/limiter.hpp"
#include "hush/core/rt_math.hpp"
#include <algorithm>
#include <cmath>
namespace hush {
void Limiter::prepare(double sr) noexcept { if(!std::isfinite(sr)||sr<8000.0)sr=48000.0; attack_=std::exp(-1.0F/(0.001F*static_cast<float>(sr))); release_=std::exp(-1.0F/(0.080F*static_cast<float>(sr))); reset(); }
void Limiter::setThreshold(float v) noexcept { threshold_=rt::finiteClamp(v,0.01F,1.0F,0.8912509F); }
void Limiter::reset() noexcept { envelope_=0.0F; gain_=1.0F; }
float Limiter::process(float x) noexcept { x=rt::sanitize(x); const float a=std::abs(x); envelope_=a>envelope_?attack_*envelope_+(1.0F-attack_)*a:release_*envelope_+(1.0F-release_)*a; const float kneeStart=threshold_*(1.0F-knee_); float desired=1.0F; if(envelope_>kneeStart){ const float soft=threshold_+knee_*threshold_*std::tanh((envelope_-threshold_)/(knee_*threshold_)); desired=std::min(1.0F,soft/std::max(envelope_,1.0e-12F)); } gain_=std::min(desired, gain_ + (1.0F-release_)*(desired-gain_)); return std::clamp(x*gain_,-1.0F,1.0F); }
}
