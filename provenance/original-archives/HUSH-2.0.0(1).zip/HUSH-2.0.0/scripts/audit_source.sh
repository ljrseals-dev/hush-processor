#!/bin/sh
set -eu
ROOT="${1:-.}"
echo "HUSH static audit: $ROOT"
echo "NOTE: text search is not a definitive security audit."
PATTERN='curl|wget|FetchContent|Cargo\.toml|Cargo\.lock|system\(|popen\(|CreateProcess|execve|fork\(|socket\(|connect\(|getaddrinfo|WinHttp|URLSession|telemetry|analytics|crash.?report|update.?check|clipboard-mcp|systemd|crontab'
if command -v rg >/dev/null 2>&1; then rg -n -i "$PATTERN" "$ROOT" --glob '!*.zip' || true; else grep -RniE "$PATTERN" "$ROOT" --exclude='*.zip' || true; fi
echo "Search complete. Manually review matches; this scan is not a security audit."
