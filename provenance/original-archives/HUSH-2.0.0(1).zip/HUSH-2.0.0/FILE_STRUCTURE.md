# HUSH 2.0.0 — complete file inventory

This is the complete source-release file list. Generated build directories and compiled binaries are excluded; rebuild locally using the offline instructions in `README.md`. `SOURCE_SHA256SUMS.txt` hashes all packaged files except itself.

## Files

- `BUILD_TEST_RESULTS.txt`
- `CHANGELOG.md`
- `CMakeLists.txt`
- `DAWCHECKER_AUDIT_INVENTORY.md`
- `DEPENDENCIES.md`
- `FILE_STRUCTURE.md`
- `LANES_AND_MARKERS_NOTES.md`
- `LICENSE`
- `MSV_ENGINE_NOTES.md`
- `PORTING_STATUS.md`
- `README.md`
- `SECURITY_AND_PRIVACY.md`
- `SOUNDCRAFT_REFERENCE_NOTES.md`
- `SOURCE_SHA256SUMS.txt`
- `evidence/SHA256SUMS_binaries.txt`
- `evidence/asan_ubsan_selected.txt`
- `evidence/audio_tests.txt`
- `evidence/build.txt`
- `evidence/cli_smoke.txt`
- `evidence/ctest.txt`
- `evidence/detector_calibration.txt`
- `evidence/hardening_readelf.txt`
- `evidence/lanes_tests.txt`
- `evidence/legacy_hushroom_1.1.1/asan_ubsan_audio.txt`
- `evidence/legacy_hushroom_1.1.1/asan_ubsan_calibration.txt`
- `evidence/legacy_hushroom_1.1.1/asan_ubsan_cli_smoke.txt`
- `evidence/legacy_hushroom_1.1.1/asan_ubsan_lanes.txt`
- `evidence/legacy_hushroom_1.1.1/asan_ubsan_module.txt`
- `evidence/legacy_hushroom_1.1.1/asan_ubsan_msv.txt`
- `evidence/legacy_hushroom_1.1.1/build_asan.txt`
- `evidence/legacy_hushroom_1.1.1/build_tsan.txt`
- `evidence/legacy_hushroom_1.1.1/tsan_msv.txt`
- `evidence/module_tests.txt`
- `evidence/msv_tests.txt`
- `evidence/toolchain.txt`
- `evidence/vendored_core_sha256.txt`
- `evidence/vendored_vs_archive.txt`
- `optional/README_OPTIONAL_TOOLS.md`
- `optional/SECURITY_HOLD.md`
- `optional/clipboard-mcp/README.md`
- `optional/clipboard-mcp/clipboard_server_advanced.py`
- `optional/clipboard-mcp/install_clipboard_server.sh`
- `optional/clipboard-mcp/requirements.txt`
- `optional/clipboard-mcp/start_clipboard_server.sh`
- `optional/server-protection/README.md`
- `optional/server-protection/dashboard/index.html`
- `optional/server-protection/install.sh`
- `optional/server-protection/monitor.sh`
- `optional/server-protection/msv-blocklist-update.sh`
- `optional/server-protection/run_dashboard.sh`
- `optional/server-protection/scripts/aide-check.sh`
- `optional/server-protection/scripts/clamav-scan.sh`
- `optional/server-protection/scripts/csf-sync.sh`
- `optional/server-protection/scripts/rkhunter-check.sh`
- `optional/server-protection/server_protection_api.py`
- `optional/server-protection/systemd/server-protection.service`
- `scripts/audit_source.sh`
- `scripts/build_gpp.sh`
- `scripts/run_all_tests.sh`
- `scripts/smoke_test.sh`
- `src/audio.cpp`
- `src/audio.hpp`
- `src/automation.cpp`
- `src/automation.hpp`
- `src/clipboard.cpp`
- `src/clipboard.hpp`
- `src/counter.cpp`
- `src/counter.hpp`
- `src/forensics.cpp`
- `src/forensics.hpp`
- `src/hash.cpp`
- `src/hash.hpp`
- `src/main.cpp`
- `src/markers.cpp`
- `src/markers.hpp`
- `src/recorder.cpp`
- `src/recorder.hpp`
- `src/result.hpp`
- `src/session.cpp`
- `src/session.hpp`
- `src/time.cpp`
- `src/time.hpp`
- `src/watermark.cpp`
- `src/watermark.hpp`
- `tests/audio_tests.cpp`
- `tests/detector_calibration.cpp`
- `tests/lanes_tests.cpp`
- `tests/module_tests.cpp`
- `tests/msv_tests.cpp`
- `third_party/dawchecker/LICENSE`
- `third_party/dawchecker/PROVENANCE.md`
- `third_party/dawchecker/SECURITY_HOLD.md`
- `third_party/dawchecker/src/core/AudioDeviceManager.cpp`
- `third_party/dawchecker/src/core/AudioDeviceManager.h`
- `third_party/dawchecker/src/core/CodecScanner.cpp`
- `third_party/dawchecker/src/core/CodecScanner.h`
- `third_party/dawchecker/src/core/DetectorTypes.h`
- `third_party/dawchecker/src/core/ENFAnalyzer.cpp`
- `third_party/dawchecker/src/core/ENFAnalyzer.h`
- `third_party/dawchecker/src/core/MSV_Engine.cpp`
- `third_party/dawchecker/src/core/MSV_Engine.h`
- `third_party/dawchecker/src/core/Neutralizers.cpp`
- `third_party/dawchecker/src/core/Neutralizers.h`
- `third_party/dawchecker/src/core/SecurityHardening.cpp`
- `third_party/dawchecker/src/core/SecurityHardening.h`
- `third_party/dawchecker/src/core/UltrasonicScanner.cpp`
- `third_party/dawchecker/src/core/UltrasonicScanner.h`
- `third_party/dawchecker/src/core/WatermarkDetector.cpp`
- `third_party/dawchecker/src/core/WatermarkDetector.h`
- `third_party/dawchecker_hardened/CHANGES.diff`
- `third_party/dawchecker_hardened/LICENSE`
- `third_party/dawchecker_hardened/PROVENANCE.md`
- `third_party/dawchecker_hardened/src/core/AudioDeviceManager.cpp`
- `third_party/dawchecker_hardened/src/core/AudioDeviceManager.h`
- `third_party/dawchecker_hardened/src/core/CodecScanner.cpp`
- `third_party/dawchecker_hardened/src/core/CodecScanner.h`
- `third_party/dawchecker_hardened/src/core/DetectorTypes.cpp`
- `third_party/dawchecker_hardened/src/core/DetectorTypes.h`
- `third_party/dawchecker_hardened/src/core/ENFAnalyzer.cpp`
- `third_party/dawchecker_hardened/src/core/ENFAnalyzer.h`
- `third_party/dawchecker_hardened/src/core/HannGoertzelBank.h`
- `third_party/dawchecker_hardened/src/core/MSV_Engine.cpp`
- `third_party/dawchecker_hardened/src/core/MSV_Engine.h`
- `third_party/dawchecker_hardened/src/core/Neutralizers.cpp`
- `third_party/dawchecker_hardened/src/core/Neutralizers.h`
- `third_party/dawchecker_hardened/src/core/RunningWindow.h`
- `third_party/dawchecker_hardened/src/core/SecurityHardening.cpp`
- `third_party/dawchecker_hardened/src/core/SecurityHardening.h`
- `third_party/dawchecker_hardened/src/core/UltrasonicScanner.cpp`
- `third_party/dawchecker_hardened/src/core/UltrasonicScanner.h`
- `third_party/dawchecker_hardened/src/core/WatermarkDetector.cpp`
- `third_party/dawchecker_hardened/src/core/WatermarkDetector.h`
- `third_party/soundcraft_notice/LICENSE-APACHE`
- `third_party/soundcraft_notice/LICENSE-MIT`
- `third_party/soundcraft_notice/NOTICE`
- `third_party/soundcraft_notice/README.md`

## Structure by responsibility

- `src/` — active HUSH C++ implementation: WAV audio, sessions, timing, automation lanes, recording-state model, markers/counter, forensics, watermarking, clipboard-check logic, hashing and CLI.
- `tests/` — audio, module, automation/marker, MSV and detector-calibration suites.
- `third_party/dawchecker_hardened/` — selected hardened DawChecker fork compiled into HUSH.
- `third_party/dawchecker/` — original DawChecker reference tree; not built. See its security hold.
- `third_party/soundcraft_notice/` — SoundCraft license/notice materials for translated model concepts.
- `optional/` — separately packaged clipboard-MCP and server-protection utilities; excluded from the DAW build and install. These require independent review.
- `scripts/` — offline build, test runner, CLI smoke tests and advisory source-pattern audit.
- `evidence/` — current HUSH 2.0.0 build/test/hardening logs, plus explicitly segregated legacy Hushroom sanitizer logs.
- Root documentation — build/dependency/security notes, porting status, audit inventory, provenance notes, changelog, roadmap and checksums.

## Completion roadmap

1. **Identity and release integrity** — HUSH branding/version, executable and build targets, consistent documentation, fresh checksums, and an explicit status/structure inventory.
2. **Reproducible build** — run the offline build from source, resolve any failures, run test suites and smoke tests, and regenerate evidence for this exact source tree.
3. **Core correctness/security review** — inspect CLI parsing, WAV parsing/writing, safe paths/overwrite behavior, session serialization, watermark and forensics boundaries, clipboard consent logic, and the active DawChecker fork.
4. **Session editing completion** — expose tested undo/redo and implement/test non-destructive clip operations (split/trim/move/fades) and automation application where supported.
5. **Real audio engine and devices** — select/approve an audio backend; implement real-time playback/recording and device lifecycle without network access.
6. **GUI** — select/approve GUI toolkit and implement transport, timeline, waveform, mixer, meters and accessible controls.
7. **MIDI and plugin architecture** — define scope and SDK/licensing policy before implementing MIDI, plugin hosting or additional formats.
8. **Release gate** — verify clean offline build, full tests, package audit, privacy/network isolation, docs and release archive. Do not call HUSH a complete DAW until the real-time engine and GUI milestones pass.

## Status semantics

A roadmap item is only marked complete when the implementation exists in this tree and its relevant tests/build checks pass. Included optional tools and historical evidence are not treated as reviewed or active HUSH features.
