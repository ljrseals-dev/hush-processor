# Changelog

## HUSH 2.0.0 — 2026-10-12

- Renamed the product and command-line executable from Hushroom to HUSH.
- Updated CMake project/target names, build scripts, CLI help, active documentation, and release metadata.
- Adopted `2.0.0` for the product rename and command-name change; no `hushroom` compatibility executable is installed.
- Preserved the existing `FKSESSION 1` session-file format and `.fks` extension so existing sessions remain compatible at the format level.
- Added `FILE_STRUCTURE.md` and a staged completion roadmap.
- Changed the historical `scripts/build_gpp.sh` entry point to use the offline CMake build, avoiding repeated monolithic compilation of the same sources.
- Ran CMake configure/build with warnings as errors; CTest passed 6/6; the CLI smoke suite passed 55/55; ELF hardening inspection refreshed. Selected ASan/UBSan suites passed 4/4; the full sanitizer suite did not complete within the execution window.
- Corrected signed PCM24 decoding, made session percent-escape decoding strict, enforced the session clip-count limit, rejected symlink session-save targets, and prevented watermark output when its label sidecar already exists (unless overwrite is explicit).
- Explicitly recorded that HUSH remains an offline DAW core, not a complete graphical real-time DAW. No GUI, live audio engine/device backend, MIDI, or plugin hosting was added in this release.
- ASan/UBSan and TSan results from Hushroom 1.1.1 were moved under `evidence/legacy_hushroom_1.1.1/` and are not presented as fresh HUSH 2.0.0 sanitizer runs.
