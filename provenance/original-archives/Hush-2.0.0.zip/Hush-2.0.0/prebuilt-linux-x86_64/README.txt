Hush 2.0.0 prebuilt Linux x86-64 binaries
Built from this source package with CMake, GCC 14.2.0, Release, HUSH_WARNINGS_AS_ERRORS=ON.
Executables: hush, hush_tests, module_tests, lanes_tests, msv_tests, detector_calibration.
These binaries are platform-specific. For other platforms, build from source with the instructions in README.md.
