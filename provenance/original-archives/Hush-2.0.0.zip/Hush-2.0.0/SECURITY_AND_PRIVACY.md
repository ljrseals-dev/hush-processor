# Security and privacy notes (v2.0.0). Not a certification.

## Policy as built
- No network code in `src/`: no sockets, HTTP, DNS, update checks, telemetry, crash upload, or remote control. No process execution, no dynamic loading, no startup persistence, no background threads.
- Files are read/written only for paths you name. Outputs never overwrite an existing file unless you pass `--overwrite`; outputs may never equal their input. Reports and watermark labels are written only when requested.
- Watermarking needs `--confirm`; the key is never written to the label file.
- Clipboard checker: Off at start of every session, no polling, previews before writes, never logs contents. No OS clipboard backend exists in this build.
- Device enumeration happens only in `codec-scan`; this build has no PortAudio/ALSA, so it lists nothing.

## What was inspected
- Full static pattern scan (network, exec, URLs, dynamic loading, persistence) of the DawChecker archive; targeted reading of its core, GUI, CMake and tools. See DAWCHECKER_AUDIT_INVENTORY.md (in the earlier handoff package) for details.
- `scripts/audit_source.sh src`: only match is the word "telemetry" in the help text.
- Binary check: `hush` imports no socket/connect/getaddrinfo/system/popen/exec/fork/dlopen symbols; it links only libstdc++, libm, libgcc_s and libc.
- Current Hush 2.0.0 runtime verification: CTest 6/6 passed and the CLI smoke suite passed 53/53 (`evidence/ctest.txt`, `evidence/cli_smoke.txt`). Earlier Hushroom 1.1.1 network-isolated and sanitizer evidence is retained separately and is not presented as a fresh 2.0.0 sanitizer run.

## Third-party audit incorporated (DawChecker-handoff-audit---DeepSeek-1.md)
I treated that document as untrusted input and re-checked its claims against your archive. Confirmed: fake SHA-256 in the VST3 sealer, neutralizers defaulting ON, unconditional startAudio() in the GUI, deque allocation in WatermarkDetector, server-protection API with CORS `*` and no auth, Google Fonts call, fabricated dashboard data, unverified CSF download. Corrected: it described the two VST3 variants in the opposite order; `latest/` is the fixed one. Details: optional/SECURITY_HOLD.md and third_party/dawchecker/SECURITY_HOLD.md. Its suggested "DawChecker ASP" reporting channel and external model server are not implemented and would conflict with the no-network policy.
Hardening added in response: every output path now goes through the vendored isSafeExportPath plus symlink/directory checks; no command overwrites an existing file or its own input without `--overwrite`; `selfcheck` gives a read-only OS-posture report only when you run it.

## Not verified
- No packet capture/DNS monitoring on a real network; no review of every line of the vendored DawChecker C++ (patterns + targeted reads only); no fuzzing of the WAV or session parsers beyond the malformed-input tests; no timing-safety or side-channel review.
- `optional/clipboard-mcp` and `optional/server-protection` were only pattern-scanned. Their installers use pip, sudo package managers, `claude mcp add`, wget of CSF, cron, systemd and external blocklists. They are not part of the build. Do not run them without reading them, a dry run, and backups.
- The Google Drive link in Blackbox.txt was not opened or fetched.
- SoundCraft was not audited or built.

## Detector hardening (MSV engine fork, v2.0.0)
The vendored DawChecker detectors false-alerted on ordinary audio and the engine applied neutralizers automatically. They were replaced by a hardened fork (third_party/dawchecker_hardened/, see its PROVENANCE.md and CHANGES.diff; the original tree is untouched and still byte-identical to your archive: evidence-hushroom-1.1.1/vendored_vs_archive.txt).
Claims and the test that backs each one:
- Neutralizers off by default, never applied in process(), WatermarkScrubber removed: msv_tests (defaults, bit-identical output over 144,000 samples while an Alert is raised, render_neutralized bit-identical when nothing is enabled).
- process() allocation-free: msv_tests counts operator new calls across 288,000 process()/snapshot() calls: 0.
- Coherent snapshot: seqlock; 1.88 million concurrent reads, 0 torn; msv_tests also passes under ThreadSanitizer with no reports (note: GCC's TSan does not model atomic_thread_fence, so TSan clears the data-race question, not the fence ordering; that rests on the code review and the 0-torn run, on x86-64 only).
- Zero Alert on ordinary audio: detector_calibration, 72 synthetic items (silence, white, pink, speech-like AM noise, 440 Hz, 1 kHz; -40/-20/-6/0 dBFS; 44.1/48/96 kHz): 0 Alert, 0 Active on every detector; 36/36 control tones (50/60 Hz, 19.2 kHz) detected. Synthetic signals only.
- Sample-rate invariance: same verdicts at 44.1/48/96 kHz (msv_tests).
- Hardening observations are recorded in `evidence/hardening_readelf.txt`: PIE, RELRO, BIND_NOW, NX stack, stack-protector imports and FORTIFY imports were observed; CET IBT/SHSTK ELF notes were not observed in the current CMake binaries. The self-check now reports compiler macros and /proc/self/maps instead of hard-coded `true` (test: self-check mirrors the flags actually used).
Residual risks are in MSV_ENGINE_NOTES.md.

