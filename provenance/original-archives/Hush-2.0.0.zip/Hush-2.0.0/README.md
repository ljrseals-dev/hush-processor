# Hush 2.0.0 (renamed from Hushroom; originally FortKnox): offline C++20 DAW core with DawChecker forensics, watermarking, clipboard checker and sessions

A command-line, offline audio/session core. **It is not yet a graphical, real-time DAW** (see PORTING_STATUS.md). No network code, no telemetry, no background processes: every file write is an explicit command.

## What works (all tested; raw outputs in evidence/)
| Module | What it does |
|---|---|
| `fk::audio` | WAV import (PCM 8/16/24/32, float32), PCM16 export, tone, gain, mix, peak/RMS/DC stats |
| `fk::time` | Tempo map with tempo changes, meters, bars|beats|ticks, samples<->seconds<->beats, SMPTE timecode incl. 29.97 drop-frame |
| `fk::forensics` | Local read-only report: Hush-native ultrasonic and mains-hum (ENF) narrowband scans; raw DawChecker detector output (labelled uncalibrated); watermark-residual check when you supply a reference; SHA-256 of the file; explicit `codec-scan` |
| `fk::watermark` | Detect and, only with `--confirm`, embed a user-chosen payload (spread-spectrum, new output file + label file, original never touched) |
| `fk::clipboard` | Consent-gated checker library: Off by default, per-action confirmation, optional bounded history, sensitive-data warnings. **No OS clipboard backend is implemented**; `sensitive-check FILE` works on text files |
| `fk::lanes` / `fk::markers` | Breakpoint automation lanes for volume, pan, mute, sends and any plugin-parameter id; Write/Touch/Latch/Touch-Latch live-capture state machine; memory locations/markers; big-counter formatter. See LANES_AND_MARKERS_NOTES.md |
| `fk::engine` | Session model (tracks, clips, gain, mute), undo/redo, strict file format, offline render to WAV |
| security | Output paths validated (no '..', symlink, directory); nothing is overwritten without `--overwrite`; `selfcheck` prints OS posture on request |
| `third_party/dawchecker_hardened/` | The hardened MSV engine + detectors (real-time safe, seqlock snapshot, neutralizers off); the original `third_party/dawchecker/` is kept untouched for reference |
| `optional/` | Your clipboard-mcp and server-protection tools, unmodified, NOT built or installed (read optional/README_OPTIONAL_TOOLS.md first) |

## Build (offline, no downloads)
Requirements: CMake 3.16+ and a C++20 compiler (verified with GCC 14.2.0).
```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DHUSH_WARNINGS_AS_ERRORS=ON
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```
The build performs no dependency downloads. A Linux x86_64 binary set is included in `prebuilt-linux-x86_64/`. `bash scripts/smoke_test.sh ./build/hush` runs the CLI integration smoke suite.

Typical flow:
```sh
hush forensics take.wav --report take_report.txt
hush wm-embed take.wav take_wm.wav --key 424242 --payload 10110010 --confirm
hush wm-detect take_wm.wav --key 424242 --bits 8
hush session-new song.fks 48000 120 && hush session-add-track song.fks Drums && hush session-add-clip song.fks 0 drums.wav 0 && hush session-render song.fks mix.wav
```

The complete status and limitations are in `Technical Manual.md` and `PORTING_STATUS.md`. This is still an offline C++20 DAW core, not yet a graphical real-time DAW; no JUCE GUI or audio-device backend is included.

## Security hold
`optional/SECURITY_HOLD.md` and `third_party/dawchecker/SECURITY_HOLD.md` list verified problems in the supplied tools (open CORS root API, fake SHA-256 in the VST3 sealer, neutralizers defaulting on). None are active in this build.

## Read before relying on results
- The DawChecker detectors were replaced by a hardened fork that no longer false-alerts on the synthetic calibration corpus (0 of 72 ordinary items; see MSV_ENGINE_NOTES.md). That corpus has no real recordings, so treat every finding as an indicator. The Hush-native scans are an independent second opinion.
- The watermark embedder is experimental. In tests it survived added noise and 16-bit requantisation, and was detected down to about -58 dBFS carrier on a 20 s program. It was not tested against resampling, lossy codecs, time-stretch or deliberate attack, and its audibility was not tested (at the default -52 dBFS carrier it sits about -32 dB below this test program's RMS, as a broadband hiss).
- All findings are indicators, never proof of tampering or authorship.
