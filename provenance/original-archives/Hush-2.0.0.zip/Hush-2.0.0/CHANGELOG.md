# Changelog

## 2.0.0 — 2026-10-12

- Renamed product and executable from Hushroom to Hush.
- Renamed CMake project/targets and build/test scripts consistently.
- Bumped major version for the externally visible product/CLI rename.
- Preserved the internal `fk` namespace and `FKSESSION 1` session signature.
- Verified a fresh CMake Release build with warnings-as-errors and all 6 CTest tests passing; CLI smoke suite passed 53/53.
- Added a current technical manual and current-release build evidence; retained 1.1.1 evidence in a separate historical directory.
- No JUCE GUI, real-time device engine, MIDI, or plugin hosting was added because none was present in the supplied archive; those remain explicit unfinished milestones.
