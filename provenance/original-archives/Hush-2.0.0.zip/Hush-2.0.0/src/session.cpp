#include "session.hpp"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <sstream>
namespace fk::engine {
namespace {
constexpr std::size_t kMaxTracks = 256, kMaxClips = 10000, kMaxFile = 4u << 20, kMaxName = 512, kMaxLanes = 512, kMaxPoints = 200000;
bool gain_ok(double g) { return std::isfinite(g) && g >= -120 && g <= 36; }
std::string esc(const std::string& s) {
  std::string o;
  for (unsigned char c : s) {
    if (c <= 32 || c == '%' || c >= 127) { char b[4]; std::snprintf(b, sizeof b, "%%%02X", c); o += b; }
    else o.push_back(static_cast<char>(c));
  }
  return o.empty() ? "%00" : o;  // "%00" encodes the empty string
}
bool unesc(const std::string& s, std::string& out) {
  out.clear();
  if (s == "%00") return true;
  for (std::size_t i = 0; i < s.size(); ++i) {
    if (s[i] != '%') { out.push_back(s[i]); continue; }
    if (i + 2 >= s.size() + 0 && i + 3 > s.size()) return false;
    unsigned v = 0;
    if (std::sscanf(s.substr(i + 1, 2).c_str(), "%2x", &v) != 1 || v == 0) return false;
    out.push_back(static_cast<char>(v));
    i += 2;
  }
  return true;
}
bool name_ok(const std::string& n) { return !n.empty() && n.size() <= kMaxName; }
}  // namespace
Status add_track(Session& s, const std::string& name) {
  if (!name_ok(name)) return Status::fail("track name must be 1..512 bytes");
  if (s.tracks.size() >= kMaxTracks) return Status::fail("track limit (256) reached");
  Track t; t.name = name;
  s.tracks.push_back(std::move(t));
  return Status::success();
}
Status set_gain(Session& s, std::size_t t, double db) {
  if (t >= s.tracks.size()) return Status::fail("no such track");
  if (!gain_ok(db)) return Status::fail("gain must be between -120 and +36 dB");
  s.tracks[t].gain_db = db;
  return Status::success();
}
Status set_mute(Session& s, std::size_t t, bool m) {
  if (t >= s.tracks.size()) return Status::fail("no such track");
  s.tracks[t].mute = m;
  return Status::success();
}
Status add_clip(Session& s, std::size_t t, const std::string& path, std::uint64_t start) {
  if (t >= s.tracks.size()) return Status::fail("no such track");
  if (!name_ok(path) || path.find('\0') != std::string::npos) return Status::fail("invalid clip path");
  std::size_t total = 0;
  for (auto& tr : s.tracks) total += tr.clips.size();
  if (total >= kMaxClips) return Status::fail("clip limit (10000) reached");
  s.tracks[t].clips.push_back({path, start});
  return Status::success();
}
Status set_mode(Session& s, std::size_t t, fk::lanes::AutomationMode m) {
  if (t >= s.tracks.size()) return Status::fail("no such track");
  s.tracks[t].mode = m; return Status::success();
}
const fk::lanes::AutomationLane* find_lane(const Track& t, const fk::lanes::AutoParam& p) {
  for (auto& l : t.lanes) if (l.param == p) return &l;
  return nullptr;
}
static fk::lanes::AutomationLane* lane_for_edit(Session& s, std::size_t t, const fk::lanes::AutoParam& p, std::string& err) {
  if (t >= s.tracks.size()) { err = "no such track"; return nullptr; }
  auto& tr = s.tracks[t];
  for (auto& l : tr.lanes) if (l.param == p) return &l;
  if (tr.lanes.size() >= kMaxLanes) { err = "lane limit (512) reached"; return nullptr; }
  tr.lanes.emplace_back(p);
  return &tr.lanes.back();
}
Status set_point(Session& s, std::size_t t, const fk::lanes::AutoParam& p, fk::lanes::Samples at, double v) {
  std::string err; auto* l = lane_for_edit(s, t, p, err); if (!l) return Status::fail(err);
  if (at < 0) return Status::fail("time must be >= 0");
  if (!std::isfinite(v)) return Status::fail("value must be finite");
  if (l->points.size() >= kMaxPoints) return Status::fail("point limit (200000) reached");
  l->set_point(at, v); return Status::success();
}
Status write_range(Session& s, std::size_t t, const fk::lanes::AutoParam& p, fk::lanes::Samples a, fk::lanes::Samples b, double v) {
  std::string err; auto* l = lane_for_edit(s, t, p, err); if (!l) return Status::fail(err);
  if (a < 0 || b <= a) return Status::fail("range must satisfy 0 <= start < end");
  if (!std::isfinite(v)) return Status::fail("value must be finite");
  l->write_range(a, b, v, p.range().def); return Status::success();
}
Result<std::size_t> thin_lane(Session& s, std::size_t t, const fk::lanes::AutoParam& p, double tol) {
  using R = Result<std::size_t>;
  if (t >= s.tracks.size()) return R::fail("no such track");
  if (!std::isfinite(tol) || tol < 0) return R::fail("tolerance must be >= 0");
  for (auto& l : s.tracks[t].lanes) if (l.param == p) return R::success(l.thin(tol));
  return R::fail("no such lane");
}
Status replace_lane(Session& s, std::size_t t, fk::lanes::AutomationLane lane) {
  std::string err; auto* l = lane_for_edit(s, t, lane.param, err); if (!l) return Status::fail(err);
  if (lane.points.size() > kMaxPoints) return Status::fail("point limit (200000) reached");
  *l = std::move(lane); return Status::success();
}
void UndoStack::checkpoint(const Session& before) {
  undo_.push_back(before);
  if (undo_.size() > max_) undo_.erase(undo_.begin());
  redo_.clear();
}
bool UndoStack::undo(Session& s) {
  if (undo_.empty()) return false;
  redo_.push_back(s); s = std::move(undo_.back()); undo_.pop_back();
  return true;
}
bool UndoStack::redo(Session& s) {
  if (redo_.empty()) return false;
  undo_.push_back(s); s = std::move(redo_.back()); redo_.pop_back();
  return true;
}
std::string serialize(const Session& s) {
  std::ostringstream o;
  o.precision(17);
  o << "FKSESSION 1\nsample_rate " << s.sample_rate << "\nbpm " << s.bpm << "\n";
  for (auto& t : s.tracks) {
    o << "track " << esc(t.name) << " " << t.gain_db << " " << (t.mute ? 1 : 0) << "\n";
    for (auto& c : t.clips) o << "clip " << esc(c.path) << " " << c.start_frame << "\n";
    if (t.mode != fk::lanes::AutomationMode::Read) { std::string m = fk::lanes::mode_label(t.mode); for (auto& ch : m) if (ch == '/') ch = '_'; o << "mode " << m << "\n"; }
    for (auto& l : t.lanes) {
      o << "lane " << esc(l.param.id()) << " " << (l.enabled ? 1 : 0) << "\n";
      for (auto& p : l.points) o << "pt " << p.at << " " << p.value << "\n";
    }
  }
  for (auto& m : s.markers.all()) {
    o << "marker " << m.number << " " << fk::markers::kind_label(m.kind) << " " << m.start << " " << m.end << " " << int(m.ruler) << " "
      << (m.track ? std::to_string(*m.track) : std::string("-1")) << " " << esc(m.name) << " " << esc(m.comments) << " ";
    if (m.color) o << int((*m.color)[0]) << "," << int((*m.color)[1]) << "," << int((*m.color)[2]); else o << "-";
    o << "\n";
  }
  return o.str();
}
Result<Session> parse(const std::string& text) {
  using R = Result<Session>;
  if (text.size() > kMaxFile) return R::fail("session file exceeds 4 MiB limit");
  std::istringstream in(text);
  std::string line;
  int ln = 0;
  auto err = [&](const std::string& m) { return R::fail("line " + std::to_string(ln) + ": " + m); };
  if (!std::getline(in, line) || (++ln, line != "FKSESSION 1")) return R::fail("line 1: not a Hush session (expected 'FKSESSION 1')");
  Session s;
  bool have_sr = false, have_bpm = false;
  while (std::getline(in, line)) {
    ++ln;
    if (line.size() > 4096) return err("line too long");
    if (line.empty()) continue;
    std::istringstream ls(line);
    std::string kw; ls >> kw;
    if (kw == "sample_rate") {
      std::uint32_t v; std::string extra;
      if (!(ls >> v) || (ls >> extra) || v < 8000 || v > 768000) return err("sample_rate must be 8000..768000");
      s.sample_rate = v; have_sr = true;
    } else if (kw == "bpm") {
      double v; std::string extra;
      if (!(ls >> v) || (ls >> extra) || !std::isfinite(v) || v < 10 || v > 960) return err("bpm must be 10..960");
      s.bpm = v; have_bpm = true;
    } else if (kw == "track") {
      std::string en, name, extra; double g; int m;
      if (!(ls >> en >> g >> m) || (ls >> extra) || !unesc(en, name) || !name_ok(name) || !gain_ok(g) || (m != 0 && m != 1))
        return err("malformed track line");
      if (s.tracks.size() >= kMaxTracks) return err("too many tracks");
      Track nt; nt.name = name; nt.gain_db = g; nt.mute = (m == 1);
      s.tracks.push_back(std::move(nt));
    } else if (kw == "clip") {
      std::string ep, path, extra; unsigned long long st;
      if (s.tracks.empty()) return err("clip before any track");
      if (!(ls >> ep >> st) || (ls >> extra) || !unesc(ep, path) || !name_ok(path)) return err("malformed clip line");
      s.tracks.back().clips.push_back({path, st});
    } else if (kw == "mode") {
      std::string m, extra;
      if (s.tracks.empty()) return err("mode before any track");
      auto pm = (ls >> m && !(ls >> extra)) ? fk::lanes::parse_mode(m) : std::nullopt;
      if (!pm) return err("unknown automation mode");
      s.tracks.back().mode = *pm;
    } else if (kw == "lane") {
      std::string eid, id, extra; int en;
      if (s.tracks.empty()) return err("lane before any track");
      if (!(ls >> eid >> en) || (ls >> extra) || !unesc(eid, id) || (en != 0 && en != 1)) return err("malformed lane line");
      auto ap = fk::lanes::AutoParam::parse(id);
      if (!ap) return err("unknown automation parameter id");
      auto& tr = s.tracks.back();
      if (tr.lanes.size() >= kMaxLanes) return err("too many lanes");
      for (auto& l : tr.lanes) if (l.param == *ap) return err("duplicate lane for this parameter");
      tr.lanes.emplace_back(*ap); tr.lanes.back().enabled = (en == 1);
    } else if (kw == "pt") {
      long long at; double v; std::string extra;
      if (s.tracks.empty() || s.tracks.back().lanes.empty()) return err("pt before any lane");
      if (!(ls >> at >> v) || (ls >> extra) || at < 0 || !std::isfinite(v)) return err("malformed pt line");
      auto& l = s.tracks.back().lanes.back();
      if (l.points.size() >= kMaxPoints) return err("too many points in lane");
      l.set_point(at, v);
    } else if (kw == "marker") {
      unsigned long long number; std::string kind, ename, ecom, color, extra; long long st, en, tr; int ruler;
      std::string comments, name;
      if (!(ls >> number >> kind >> st >> en >> ruler >> tr >> ename >> ecom >> color) || (ls >> extra) || number == 0 || number > 4000000000ULL)
        return err("malformed marker line");
      auto k = fk::markers::parse_kind(kind);
      if (!k || !unesc(ename, name) || !unesc(ecom, comments) || ruler < 1 || ruler > 5 || tr < -1) return err("malformed marker line");
      fk::markers::MemoryLocation m;
      m.number = static_cast<std::uint32_t>(number); m.kind = *k; m.start = st; m.end = en; m.ruler = static_cast<std::uint8_t>(ruler);
      m.name = name; m.comments = comments;
      if (tr >= 0) m.track = static_cast<std::uint32_t>(tr);
      if (color != "-") {
        int r, g, b; char c1, c2;
        std::istringstream cs(color);
        if (!(cs >> r >> c1 >> g >> c2 >> b) || c1 != ',' || c2 != ',' || r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255) return err("bad marker color");
        m.color = std::array<std::uint8_t, 3>{static_cast<std::uint8_t>(r), static_cast<std::uint8_t>(g), static_cast<std::uint8_t>(b)};
      }
      if (auto st2 = s.markers.insert_raw(m); !st2) return err(st2.error);
    } else return err("unknown keyword '" + kw.substr(0, 32) + "'");
  }
  if (!have_sr || !have_bpm) return R::fail("missing sample_rate or bpm");
  return R::success(std::move(s));
}
Result<Session> load(const std::filesystem::path& p) {
  std::ifstream f(p, std::ios::binary);
  if (!f) return Result<Session>::fail("cannot open session: " + p.string());
  std::ostringstream ss; ss << f.rdbuf();
  return parse(ss.str());
}
Status save(const std::filesystem::path& p, const Session& s, bool overwrite) {
  if (!overwrite && std::filesystem::exists(p)) return Status::fail("refusing to overwrite existing file: " + p.string());
  std::ofstream f(p, std::ios::binary | std::ios::trunc);
  if (!f) return Status::fail("cannot create: " + p.string());
  f << serialize(s);
  return f ? Status::success() : Status::fail("write failed");
}
Result<fk::audio::AudioBuffer> render(const Session& s, const std::filesystem::path& base) {
  using R = Result<fk::audio::AudioBuffer>;
  std::vector<float> acc;
  std::uint16_t channels = 0;
  try {
    for (auto& t : s.tracks) {
      if (t.mute) continue;
      float g = static_cast<float>(std::pow(10.0, t.gain_db / 20.0));
      for (auto& c : t.clips) {
        std::filesystem::path p = c.path;
        if (p.is_relative()) p = base / p;
        auto a = fk::audio::read_wav(p);
        if (a.sample_rate != s.sample_rate) return R::fail("clip sample rate differs from session: " + c.path);
        if (!channels) channels = a.channels;
        if (a.channels != channels) return R::fail("clip channel count differs from other clips: " + c.path);
        std::size_t offset = static_cast<std::size_t>(c.start_frame) * channels;
        if (c.start_frame > (1ULL << 32)) return R::fail("clip start too far");
        if (acc.size() < offset + a.samples.size()) acc.resize(offset + a.samples.size(), 0.0f);
        const fk::lanes::AutomationLane* vol = fk::lanes::reads(t.mode) ? find_lane(t, fk::lanes::AutoParam::volume()) : nullptr;
        const fk::lanes::AutomationLane* mut = fk::lanes::reads(t.mode) ? find_lane(t, fk::lanes::AutoParam::mute()) : nullptr;
        if (vol && (vol->points.empty() || !vol->enabled)) vol = nullptr;
        if (mut && (mut->points.empty() || !mut->enabled)) mut = nullptr;
        // Volume and mute lanes are applied per frame; pan, send and plugin-parameter lanes are stored but NOT rendered.
        for (std::size_t f = 0; f < a.frames(); ++f) {
          float gg = g;
          const fk::lanes::Samples pos = static_cast<fk::lanes::Samples>(c.start_frame + f);
          if (vol) gg *= static_cast<float>(std::pow(10.0, vol->value_at(pos, 0.0) / 20.0));
          if (mut && mut->value_at(pos, 0.0) >= 0.5) gg = 0.0f;
          for (std::uint16_t ch = 0; ch < channels; ++ch) acc[offset + f * channels + ch] += a.samples[f * channels + ch] * gg;
        }
      }
    }
  } catch (const std::exception& e) { return R::fail(e.what()); }
  if (acc.empty()) return R::fail("nothing to render (no unmuted clips)");
  return R::success(fk::audio::AudioBuffer{s.sample_rate, channels, std::move(acc)});
}
}  // namespace fk::engine
