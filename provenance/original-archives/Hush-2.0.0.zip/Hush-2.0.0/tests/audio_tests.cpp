#include "audio.hpp"
#include <filesystem>
#include <iostream>
#include <stdexcept>
static void check(bool ok,const char*m){if(!ok)throw std::runtime_error(m);}
int main(){using namespace fk::audio;auto t=make_tone(.25,1000,.5,48000,2);check(t.frames()==12000,"tone frame count");auto s=analyze(t);check(s.peak>.49&&s.peak<.501,"tone peak");check(s.rms>.34&&s.rms<.36,"tone RMS");auto q=apply_gain(t,-6);check(analyze(q).peak<analyze(t).peak*.51,"gain reduction");auto m=mix({t,t},{0,-6});check(m.frames()==t.frames(),"mix frame count");auto p=std::filesystem::temp_directory_path()/"hush_test_roundtrip.wav";write_wav_pcm16(p,t);auto r=read_wav(p);check(r.sample_rate==48000&&r.channels==2&&r.frames()==12000,"roundtrip metadata");check(analyze(r).peak>.48,"roundtrip signal");std::filesystem::remove(p);std::cout<<"PASS: tone generation, peak/RMS, gain, mix, PCM16 WAV roundtrip\n";}
