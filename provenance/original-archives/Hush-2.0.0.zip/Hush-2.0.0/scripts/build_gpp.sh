#!/bin/bash
# Legacy direct-g++ offline build path (slower than CMake). Usage: scripts/build_gpp.sh (env OUT=dir changes output dir)
set -e
cd "$(dirname "$0")/.."
OUT=${OUT:-build_gpp}; mkdir -p "$OUT"
D=third_party/dawchecker_hardened/src
# WP5(a): real hardening flags, applied to ALL code including the DawChecker fork.
HARD="-fstack-protector-strong -D_FORTIFY_SOURCE=3 -fcf-protection=full -fPIE"
LINKHARD="-pie -Wl,-z,relro,-z,now,-z,noexecstack"
FLAGS="-std=c++20 -O2 -Wall -Wextra -Wpedantic -Werror $HARD -Isrc -I$D"
DC="$D/core/DetectorTypes.cpp $D/core/ENFAnalyzer.cpp $D/core/UltrasonicScanner.cpp $D/core/WatermarkDetector.cpp $D/core/MSV_Engine.cpp $D/core/Neutralizers.cpp $D/core/CodecScanner.cpp $D/core/AudioDeviceManager.cpp $D/core/SecurityHardening.cpp"
LIB="src/audio.cpp src/hash.cpp src/time.cpp src/watermark.cpp src/clipboard.cpp src/forensics.cpp src/session.cpp src/automation.cpp src/recorder.cpp src/markers.cpp src/counter.cpp"
DCO=""
for f in $DC; do g++ $FLAGS -c "$f" -o "$OUT/dc_$(basename "$f" .cpp).o"; DCO="$DCO $OUT/dc_$(basename "$f" .cpp).o"; done
g++ $FLAGS $LIB src/main.cpp $DCO $LINKHARD -o "$OUT/hush"; echo "built hush"
if [ -f tests/module_tests.cpp ]; then
  g++ $FLAGS $LIB tests/module_tests.cpp $DCO $LINKHARD -o "$OUT/module_tests"
  g++ $FLAGS src/audio.cpp tests/audio_tests.cpp $LINKHARD -o "$OUT/hush_tests"
  g++ $FLAGS tests/msv_tests.cpp $DCO $LINKHARD -o "$OUT/msv_tests"
  g++ $FLAGS tests/detector_calibration.cpp $DCO $LINKHARD -o "$OUT/detector_calibration"
  g++ $FLAGS $LIB tests/lanes_tests.cpp $DCO $LINKHARD -o "$OUT/lanes_tests"
  echo "built tests"
fi
echo "run: scripts/run_all_tests.sh $OUT"
