# Feature status (v2.0.0, product name Hush; renamed from Hushroom)
Legend: **Implemented** = built and covered by a passing test here. **Partial** = some of it. **Not implemented** = absent.

| Feature | Status | Notes |
|---|---|---|
| C++20, offline build | Implemented | CMake Release build verified with GCC 14.2.0; CTest 6/6 passed |
| WAV import/export, tone, gain, mix, stats | Implemented | PCM16 output only |
| Tempo map, meter, BBT, timecode (24/25/30/29.97DF) | Implemented | `fk::time`, 15 tests incl. drop-frame round trip |
| Session model, serialisation, undo/redo, offline render | Partial | CLI is one command per edit; undo/redo is a tested library, not exposed in the CLI; no timeline editing commands (split/trim/move) or fades; automation is a separate offline lane model with only some parameters applied at render |
| DawChecker forensics (ultrasonic/ENF/residual/codec names) | Implemented | Now runs the HARDENED FORK detectors (calibrated on a synthetic corpus only) beside the Hush-native scans; the original detectors' false alerts are gone (changed test documented in BUILD_TEST_RESULTS.txt) |
| MSV_Engine aggregate tamper score | Implemented, internal | In the fork (seqlock snapshot); NOT exposed by the CLI: no `--tamper-score` flag; it is an uncalibrated indicator |
| Neutralizers (ENF notch, ultrasonic rolloff) | Library only | Off by default; reachable only through the explicit offline `render_neutralized()`; not in the CLI. WatermarkScrubber (watermark removal) was REMOVED from the fork |
| Watermark detection (own spread-spectrum) | Implemented | z-score vs 64 wrong-key nulls; 0/30 false positives on a small synthetic set |
| Watermark embedding | Implemented (experimental) | Explicit `--confirm`, new file + label; audibility and robustness beyond noise/requantisation untested |
| Clipboard checker logic | Implemented | Fake-provider tests: Off by default, confirm/token, history bounds/expiry |
| OS clipboard read/write backend | Not implemented | Needs a per-platform backend you approve; default provider reports "no backend" |
| Clipboard MCP server (Python) | Included, unmodified, not built | `optional/clipboard-mcp` |
| Server protection toolkit | Included, unmodified, not built | `optional/server-protection`; not reviewed beyond a pattern scan |
| SecurityHardening helpers (safe export path, selfcheck) | Implemented | `selfcheck` is explicit and read-only; checkedMul/secureZero are vendored but not used by Hush code |
| Breakpoint automation lanes (volume, pan, mute, sends, any plugin parameter id), automation modes, edit ops (point, range, thin, shift) | Implemented (data + offline) | Translated from SoundCraft's model crate; volume and mute applied at render, other lanes stored only |
| Live Write / Touch / Latch / Touch-Latch capture | Implemented as a tested state machine, no live feed | Original code; replayed with `lane-record`; no audio/GUI to feed it; live Trim not implemented |
| Markers and memory locations | Implemented | Marker/Selection/None kinds, numbering, rulers 1-5, recall, next/prev; track groups not ported |
| Big counter | Formatter implemented, no window | `hush counter` |
| Real-time playback/recording, device I/O | Not implemented | No audio backend approved |
| GUI (transport, timeline, mixer, waveform) | Not implemented | No GUI toolkit approved; Dear ImGui not supplied |
| MIDI, automation lanes, plugin hosting (VST3/CLAP/AU), video | Not implemented | SoundCraft has these in Rust; not ported (SOUNDCRAFT_REFERENCE_NOTES.md) |
| Lossless/other formats (FLAC, AIFF, MP3) | Not implemented | WAV only |
