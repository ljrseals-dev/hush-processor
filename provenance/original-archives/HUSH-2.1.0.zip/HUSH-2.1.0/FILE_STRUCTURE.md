# HUSH 2.1.0 — complete file inventory

This inventory is generated from the source package. Build directories and compiled binaries are excluded. `SOURCE_SHA256SUMS.txt` contains hashes of packaged files except itself.

## Files

- `.github/workflows/ci.yml`
- `BUILD_TEST_RESULTS.txt`
- `CHANGELOG.md`
- `CMakeLists.txt`
- `DAWCHECKER_AUDIT_INVENTORY.md`
- `DEPENDENCIES.md`
- `FILE_STRUCTURE.md`
- `LANES_AND_MARKERS_NOTES.md`
- `LICENSE`
- `MSV_ENGINE_NOTES.md`
- `PORTING_STATUS.md`
- `README.md`
- `SECURITY_AND_PRIVACY.md`
- `SOUNDCRAFT_REFERENCE_NOTES.md`
- `evidence/SHA256SUMS_binaries.txt`
- `evidence/asan_ubsan_selected.txt`
- `evidence/audio_tests.txt`
- `evidence/build_gcc.txt`
- `evidence/cli_smoke.txt`
- `evidence/ctest.txt`
- `evidence/ctest_clang.txt`
- `evidence/ctest_gcc.txt`
- `evidence/detector_calibration.txt`
- `evidence/gui_xvfb_smoke.txt`
- `evidence/hardening_readelf.txt`
- `evidence/install_gcc.txt`
- `evidence/installed_hush_help.txt`
- `evidence/lanes_tests.txt`
- `evidence/legacy_hush_2.0.0/audio_tests.txt`
- `evidence/legacy_hush_2.0.0/build.txt`
- `evidence/legacy_hush_2.0.0/cli_smoke.txt`
- `evidence/legacy_hush_2.0.0/ctest.txt`
- `evidence/legacy_hush_2.0.0/detector_calibration.txt`
- `evidence/legacy_hush_2.0.0/hardening_readelf.txt`
- `evidence/legacy_hush_2.0.0/lanes_tests.txt`
- `evidence/legacy_hush_2.0.0/module_tests.txt`
- `evidence/legacy_hush_2.0.0/msv_tests.txt`
- `evidence/legacy_hush_2.0.0/toolchain.txt`
- `evidence/legacy_hushroom_1.1.1/asan_ubsan_audio.txt`
- `evidence/legacy_hushroom_1.1.1/asan_ubsan_calibration.txt`
- `evidence/legacy_hushroom_1.1.1/asan_ubsan_cli_smoke.txt`
- `evidence/legacy_hushroom_1.1.1/asan_ubsan_lanes.txt`
- `evidence/legacy_hushroom_1.1.1/asan_ubsan_module.txt`
- `evidence/legacy_hushroom_1.1.1/asan_ubsan_msv.txt`
- `evidence/legacy_hushroom_1.1.1/build_asan.txt`
- `evidence/legacy_hushroom_1.1.1/build_tsan.txt`
- `evidence/legacy_hushroom_1.1.1/tsan_msv.txt`
- `evidence/module_tests.txt`
- `evidence/msv_tests.txt`
- `evidence/source_audit.txt`
- `evidence/toolchain.txt`
- `evidence/vendored_core_sha256.txt`
- `evidence/vendored_vs_archive.txt`
- `optional/README_OPTIONAL_TOOLS.md`
- `optional/SECURITY_HOLD.md`
- `optional/clipboard-mcp/README.md`
- `optional/clipboard-mcp/clipboard_server_advanced.py`
- `optional/clipboard-mcp/install_clipboard_server.sh`
- `optional/clipboard-mcp/requirements.txt`
- `optional/clipboard-mcp/start_clipboard_server.sh`
- `optional/server-protection/README.md`
- `optional/server-protection/dashboard/index.html`
- `optional/server-protection/install.sh`
- `optional/server-protection/monitor.sh`
- `optional/server-protection/msv-blocklist-update.sh`
- `optional/server-protection/run_dashboard.sh`
- `optional/server-protection/scripts/aide-check.sh`
- `optional/server-protection/scripts/clamav-scan.sh`
- `optional/server-protection/scripts/csf-sync.sh`
- `optional/server-protection/scripts/rkhunter-check.sh`
- `optional/server-protection/server_protection_api.py`
- `optional/server-protection/systemd/server-protection.service`
- `scripts/audit_source.sh`
- `scripts/build_gpp.sh`
- `scripts/run_all_tests.sh`
- `scripts/smoke_test.sh`
- `src/audio.cpp`
- `src/audio.hpp`
- `src/audio_engine.cpp`
- `src/audio_engine.hpp`
- `src/automation.cpp`
- `src/automation.hpp`
- `src/clipboard.cpp`
- `src/clipboard.hpp`
- `src/counter.cpp`
- `src/counter.hpp`
- `src/forensics.cpp`
- `src/forensics.hpp`
- `src/gui_x11.cpp`
- `src/hash.cpp`
- `src/hash.hpp`
- `src/main.cpp`
- `src/markers.cpp`
- `src/markers.hpp`
- `src/midi.cpp`
- `src/midi.hpp`
- `src/plugin_host.cpp`
- `src/plugin_host.hpp`
- `src/portaudio_backend.cpp`
- `src/portaudio_backend.hpp`
- `src/recorder.cpp`
- `src/recorder.hpp`
- `src/result.hpp`
- `src/session.cpp`
- `src/session.hpp`
- `src/time.cpp`
- `src/time.hpp`
- `src/watermark.cpp`
- `src/watermark.hpp`
- `tests/audio_tests.cpp`
- `tests/detector_calibration.cpp`
- `tests/lanes_tests.cpp`
- `tests/module_tests.cpp`
- `tests/msv_tests.cpp`
- `tests/realtime_tests.cpp`
- `third_party/dawchecker/LICENSE`
- `third_party/dawchecker/PROVENANCE.md`
- `third_party/dawchecker/SECURITY_HOLD.md`
- `third_party/dawchecker/src/core/AudioDeviceManager.cpp`
- `third_party/dawchecker/src/core/AudioDeviceManager.h`
- `third_party/dawchecker/src/core/CodecScanner.cpp`
- `third_party/dawchecker/src/core/CodecScanner.h`
- `third_party/dawchecker/src/core/DetectorTypes.h`
- `third_party/dawchecker/src/core/ENFAnalyzer.cpp`
- `third_party/dawchecker/src/core/ENFAnalyzer.h`
- `third_party/dawchecker/src/core/MSV_Engine.cpp`
- `third_party/dawchecker/src/core/MSV_Engine.h`
- `third_party/dawchecker/src/core/Neutralizers.cpp`
- `third_party/dawchecker/src/core/Neutralizers.h`
- `third_party/dawchecker/src/core/SecurityHardening.cpp`
- `third_party/dawchecker/src/core/SecurityHardening.h`
- `third_party/dawchecker/src/core/UltrasonicScanner.cpp`
- `third_party/dawchecker/src/core/UltrasonicScanner.h`
- `third_party/dawchecker/src/core/WatermarkDetector.cpp`
- `third_party/dawchecker/src/core/WatermarkDetector.h`
- `third_party/dawchecker_hardened/CHANGES.diff`
- `third_party/dawchecker_hardened/LICENSE`
- `third_party/dawchecker_hardened/PROVENANCE.md`
- `third_party/dawchecker_hardened/src/core/AudioDeviceManager.cpp`
- `third_party/dawchecker_hardened/src/core/AudioDeviceManager.h`
- `third_party/dawchecker_hardened/src/core/CodecScanner.cpp`
- `third_party/dawchecker_hardened/src/core/CodecScanner.h`
- `third_party/dawchecker_hardened/src/core/DetectorTypes.cpp`
- `third_party/dawchecker_hardened/src/core/DetectorTypes.h`
- `third_party/dawchecker_hardened/src/core/ENFAnalyzer.cpp`
- `third_party/dawchecker_hardened/src/core/ENFAnalyzer.h`
- `third_party/dawchecker_hardened/src/core/HannGoertzelBank.h`
- `third_party/dawchecker_hardened/src/core/MSV_Engine.cpp`
- `third_party/dawchecker_hardened/src/core/MSV_Engine.h`
- `third_party/dawchecker_hardened/src/core/Neutralizers.cpp`
- `third_party/dawchecker_hardened/src/core/Neutralizers.h`
- `third_party/dawchecker_hardened/src/core/RunningWindow.h`
- `third_party/dawchecker_hardened/src/core/SecurityHardening.cpp`
- `third_party/dawchecker_hardened/src/core/SecurityHardening.h`
- `third_party/dawchecker_hardened/src/core/UltrasonicScanner.cpp`
- `third_party/dawchecker_hardened/src/core/UltrasonicScanner.h`
- `third_party/dawchecker_hardened/src/core/WatermarkDetector.cpp`
- `third_party/dawchecker_hardened/src/core/WatermarkDetector.h`
- `third_party/soundcraft_notice/LICENSE-APACHE`
- `third_party/soundcraft_notice/LICENSE-MIT`
- `third_party/soundcraft_notice/NOTICE`
- `third_party/soundcraft_notice/README.md`

## Structure by responsibility

- `.github/workflows/ci.yml` — pinned-action CI matrix for Ubuntu, Windows and macOS. It has not been run on remote hosted runners.
- `src/` — WAV handling, sessions, offline render, real-time mixer, opt-in PortAudio backend, Linux/X11 GUI, MIDI event queue, plugin DSP interface, automation, markers, forensics, watermarking, clipboard-check logic, hashing and CLI.
- `tests/` — audio, realtime/MIDI/plugin interface, module/session, automation/marker, MSV and detector-calibration tests.
- `third_party/dawchecker_hardened/` — selected hardened DawChecker fork compiled into HUSH.
- `third_party/dawchecker/` — original DawChecker reference tree; not built.
- `third_party/soundcraft_notice/` — SoundCraft license and notice material; no Rust code is included.
- `optional/` — separate clipboard-MCP and server-protection utilities; excluded from the DAW build and install, and not fully audited.
- `scripts/` — offline build, test runner, CLI smoke tests and advisory source-pattern audit.
- `evidence/` — HUSH 2.1.0 GCC/Clang test results, sanitizer subset, GUI launch smoke, binary hashes, and segregated historical logs.
- Root documentation — dependency/provenance/security notes, status, changelog, audit inventory and source checksums.

## Completion status

Implemented and tested in this package: offline WAV/session workflows, v1-compatible/v2 session format, clip move/trim/split/fades, bounded undo/redo APIs, offline render, preloaded real-time mixer core, opt-in PortAudio output, Linux/X11 GUI, MIDI event queue, and in-process plugin chain interface.

Not yet a production-complete DAW: the GUI does not yet expose clip drag/split/trim/fades; no audio recording/monitoring; no OS MIDI I/O; no VST3/CLAP/AU binary hosting or plugin sandbox; no Windows/macOS GUI/device backend; physical audio hardware was not tested; no independent security certification.

## Remaining release roadmap

1. Add full clip selection/drag/split/trim/fade controls to the GUI and wire every edit into undo/redo.
2. Add device selection, stream hotplug recovery, latency tests, recording and monitoring.
3. Add OS MIDI I/O and MIDI editor/track support.
4. Select a plugin standard and SDK/licensing policy; implement sandboxing before third-party binary plugin loading.
5. Port GUI/device backends to Windows and macOS and execute the new CI matrix on hosted runners.
6. Run full sanitizer suites, parser fuzzing, real-device playback tests, network-isolation checks and independent third-party review.

## Status semantics

A feature is not marked complete merely because an interface exists. The evidence files distinguish code-level tests from hardware, cross-platform, and security claims.
