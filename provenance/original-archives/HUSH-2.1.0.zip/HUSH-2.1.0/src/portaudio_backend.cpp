#include "portaudio_backend.hpp"
#include <algorithm>
#include <cstring>
#include <limits>
#include <memory>

#if defined(HUSH_HAS_PORTAUDIO)
// Minimal declarations of the stable PortAudio C ABI. No PortAudio headers are copied
// into this project; the system-provided library is an optional build dependency.
extern "C" {
typedef int PaError; typedef void PaStream; typedef double PaTime;
typedef unsigned long PaSampleFormat; typedef unsigned long PaStreamFlags; typedef unsigned long PaStreamCallbackFlags;
typedef struct PaStreamParameters { int device; int channelCount; PaSampleFormat sampleFormat; PaTime suggestedLatency; void* hostApiSpecificStreamInfo; } PaStreamParameters;
typedef struct PaDeviceInfo { int structVersion; const char* name; int hostApi; int maxInputChannels; int maxOutputChannels; PaTime defaultLowInputLatency; PaTime defaultLowOutputLatency; PaTime defaultHighInputLatency; PaTime defaultHighOutputLatency; double defaultSampleRate; } PaDeviceInfo;
typedef struct PaStreamCallbackTimeInfo { PaTime inputBufferAdcTime; PaTime currentTime; PaTime outputBufferDacTime; } PaStreamCallbackTimeInfo;
typedef int (*PaStreamCallback)(const void*, void*, unsigned long, const PaStreamCallbackTimeInfo*, PaStreamCallbackFlags, void*);
PaError Pa_Initialize(void); PaError Pa_Terminate(void); PaError Pa_GetDeviceCount(void); int Pa_GetDefaultOutputDevice(void);
const PaDeviceInfo* Pa_GetDeviceInfo(int); PaError Pa_OpenStream(PaStream**, const PaStreamParameters*, const PaStreamParameters*, double, unsigned long, PaStreamFlags, PaStreamCallback, void*);
PaError Pa_StartStream(PaStream*); PaError Pa_StopStream(PaStream*); PaError Pa_CloseStream(PaStream*); const char* Pa_GetErrorText(PaError);
}
namespace { constexpr PaSampleFormat paFloat32 = 0x00000001UL; constexpr int paContinue = 0; constexpr int paAbort = 2; }
#endif

namespace hush::rt {
struct PortAudioBackend::Impl {
  Callback callback{}; void* context{}; bool initialized{}; std::uint16_t channels{};
#if defined(HUSH_HAS_PORTAUDIO)
  PaStream* stream{};
#endif
};
PortAudioBackend::PortAudioBackend() : impl_(std::make_unique<Impl>()) {}
PortAudioBackend::~PortAudioBackend() { stop(); }
bool PortAudioBackend::available() noexcept {
#if defined(HUSH_HAS_PORTAUDIO)
  return true;
#else
  return false;
#endif
}
fk::Result<std::vector<OutputDeviceInfo>> PortAudioBackend::enumerate_outputs() {
#if defined(HUSH_HAS_PORTAUDIO)
  if (Pa_Initialize() != 0) return fk::Result<std::vector<OutputDeviceInfo>>::fail("PortAudio initialization failed");
  const int count = Pa_GetDeviceCount();
  std::vector<OutputDeviceInfo> out;
  if (count < 0) { Pa_Terminate(); return fk::Result<std::vector<OutputDeviceInfo>>::fail("PortAudio could not enumerate devices"); }
  for (int i = 0; i < count; ++i) {
    const auto* d = Pa_GetDeviceInfo(i);
    if (d && d->maxOutputChannels > 0) out.push_back({i, d->name ? d->name : "(unnamed device)", d->maxOutputChannels, d->defaultSampleRate});
  }
  Pa_Terminate(); return fk::Result<std::vector<OutputDeviceInfo>>::success(std::move(out));
#else
  return fk::Result<std::vector<OutputDeviceInfo>>::fail("PortAudio backend not built; install/approve PortAudio and rebuild with HUSH_ENABLE_PORTAUDIO=ON");
#endif
}
fk::Status PortAudioBackend::start(std::uint32_t rate, std::uint16_t channels, std::size_t block,
                                   Callback callback, void* context) {
#if defined(HUSH_HAS_PORTAUDIO)
  if (impl_->stream) return fk::Status::fail("PortAudio stream already started");
  if (!callback || (channels != 1 && channels != 2) || rate < 8000 || rate > 384000 || block == 0 || block > 8192)
    return fk::Status::fail("invalid PortAudio stream configuration");
  if (Pa_Initialize() != 0) return fk::Status::fail("PortAudio initialization failed");
  impl_->initialized = true; const int device = Pa_GetDefaultOutputDevice();
  if (device < 0) { stop(); return fk::Status::fail("no default output device; choose/configure a device in the operating system"); }
  const auto* info = Pa_GetDeviceInfo(device);
  if (!info || info->maxOutputChannels < channels) { stop(); return fk::Status::fail("default output device does not support requested channels"); }
  PaStreamParameters output{device, static_cast<int>(channels), paFloat32, info->defaultLowOutputLatency, nullptr};
  impl_->callback = callback; impl_->context = context; impl_->channels = channels;
  auto trampoline = [](const void*, void* out, unsigned long frames, const PaStreamCallbackTimeInfo*, PaStreamCallbackFlags, void* user) -> int {
    auto* self = static_cast<Impl*>(user);
    if (!self || !self->callback || !out) return paAbort;
    self->callback(self->context, static_cast<float*>(out), static_cast<std::size_t>(frames), self->channels);
    return paContinue;
  };
  const auto err = Pa_OpenStream(&impl_->stream, nullptr, &output, static_cast<double>(rate), static_cast<unsigned long>(block), 0, trampoline, impl_.get());
  if (err != 0) { impl_->stream = nullptr; stop(); return fk::Status::fail(std::string("PortAudio open failed: ") + Pa_GetErrorText(err)); }
  const auto started = Pa_StartStream(impl_->stream);
  if (started != 0) { const std::string msg = std::string("PortAudio start failed: ") + Pa_GetErrorText(started); stop(); return fk::Status::fail(msg); }
  return fk::Status::success();
#else
  (void)rate; (void)channels; (void)block; (void)callback; (void)context;
  return fk::Status::fail("PortAudio backend not built; configure with HUSH_ENABLE_PORTAUDIO=ON");
#endif
}
void PortAudioBackend::stop() noexcept {
#if defined(HUSH_HAS_PORTAUDIO)
  if (impl_ && impl_->stream) { Pa_StopStream(impl_->stream); Pa_CloseStream(impl_->stream); impl_->stream = nullptr; }
  if (impl_ && impl_->initialized) { Pa_Terminate(); impl_->initialized = false; }
#endif
}
} // namespace hush::rt
