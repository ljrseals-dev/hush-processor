#pragma once
#include "audio_engine.hpp"
#include <memory>
#include <string>
#include <vector>

namespace hush::rt {
struct OutputDeviceInfo { int index{-1}; std::string name; int max_output_channels{}; double default_sample_rate{}; };
class PortAudioBackend final : public AudioDeviceBackend {
 public:
  PortAudioBackend();
  ~PortAudioBackend() override;
  PortAudioBackend(const PortAudioBackend&) = delete;
  PortAudioBackend& operator=(const PortAudioBackend&) = delete;
  static bool available() noexcept;
  static fk::Result<std::vector<OutputDeviceInfo>> enumerate_outputs();
  fk::Status start(std::uint32_t sample_rate, std::uint16_t channels, std::size_t block_frames,
                   Callback callback, void* context) override;
  void stop() noexcept override;
  const char* name() const noexcept override { return "PortAudio"; }
 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};
} // namespace hush::rt
