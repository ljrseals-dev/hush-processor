#include "hush/audio/engine.hpp"
#include <array>
#include <cmath>
#include <cstdio>
int main() {
 hush::Engine engine;
 if(!engine.prepare({48000.0,128U,2U})) return 1;
 if(engine.addTrack()==0U) return 2;
 std::array<float,128> in{},left{},right{};
 const float* inputs[2]{in.data(),in.data()};
 for(std::size_t block=0U;block<100U;++block) {
  for(std::size_t i=0U;i<in.size();++i) in[i]=0.2F*std::sin(6.28318530718F*440.0F*static_cast<float>(block*in.size()+i)/48000.0F);
  engine.processAll(inputs,left.data(),right.data(),in.size());
 }
 std::printf("Offline render completed; peak %.4f\n",engine.mixer().master().meter().peak);
 return engine.mixer().master().meter().peak>0.0F?0:3;
}
