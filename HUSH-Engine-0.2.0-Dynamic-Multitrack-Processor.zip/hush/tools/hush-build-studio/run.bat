@echo off
py "%~dp0server.py"
