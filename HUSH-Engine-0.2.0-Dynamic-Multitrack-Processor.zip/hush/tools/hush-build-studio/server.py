#!/usr/bin/env python3
"""Local-only HUSH Build Studio: paste source files and invoke CMake safely."""
from __future__ import annotations
import json, os, re, shutil, subprocess, tempfile, threading, zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = int(os.environ.get("HUSH_BUILD_STUDIO_PORT", "8765"))
MAX_BODY = 8 * 1024 * 1024
BUILD_LOCK = threading.Lock()

class Handler(BaseHTTPRequestHandler):
    server_version = "HUSHBuildStudio/1.0"
    def log_message(self, fmt, *args):
        print("[HUSH Build Studio] " + (fmt % args))
    def send_bytes(self, code, data, content_type="application/json; charset=utf-8"):
        self.send_response(code); self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data))); self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/status":
            self.send_bytes(200, json.dumps({"cmake": shutil.which("cmake"), "compiler": shutil.which("c++") or shutil.which("g++") or shutil.which("clang++"), "platform": os.name}).encode()); return
        if path in ("/", "/index.html"):
            p = ROOT / "index.html"; self.send_bytes(200, p.read_bytes(), "text/html; charset=utf-8"); return
        self.send_bytes(404, b'{"error":"not found"}')
    def do_POST(self):
        route = urlparse(self.path).path
        if route not in ("/api/build", "/api/source-zip"):
            self.send_bytes(404, b'{"error":"not found"}'); return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > MAX_BODY: raise ValueError("Request must be between 1 byte and 8 MiB.")
            payload = json.loads(self.rfile.read(length))
            files = payload.get("files")
            if not isinstance(files, list) or not files: raise ValueError("Paste at least one file.")
            if len(files) > 500: raise ValueError("Maximum 500 files per request.")
            if route == "/api/source-zip":
                import io, base64
                buf = io.BytesIO()
                with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                    for entry in files:
                        raw = entry.get("path", "").replace('\\', '/')
                        rel = PurePosixPath(raw)
                        if not raw or rel.is_absolute() or any(p in ("", ".", "..") for p in rel.parts) or re.match(r"^[A-Za-z]:", raw): raise ValueError(f"Unsafe relative path: {raw!r}")
                        content = entry.get("content")
                        if not isinstance(content, str): raise ValueError("Each file must contain string path and content fields.")
                        z.writestr(str(rel), content)
                self.send_bytes(200, json.dumps({"ok":True,"zip_base64":base64.b64encode(buf.getvalue()).decode("ascii"),"zip_name":"HUSH-pasted-source.zip"}).encode()); return
            if not any(x.get("path") == "CMakeLists.txt" for x in files): raise ValueError("A root CMakeLists.txt is required to create a build.")
            if not shutil.which("cmake"): raise ValueError("CMake was not found. Install CMake 3.20+ and reopen Build Studio.")
            if not (shutil.which("c++") or shutil.which("g++") or shutil.which("clang++") or os.name == "nt" and shutil.which("cl")):
                raise ValueError("No C++ compiler found on PATH. Install a compiler toolchain first.")
            if not BUILD_LOCK.acquire(blocking=False): raise ValueError("A build is already running. Wait for it to finish.")
            try: result = self.build(files, bool(payload.get("run_tests", True)))
            finally: BUILD_LOCK.release()
            self.send_bytes(200, json.dumps(result).encode())
        except (ValueError, json.JSONDecodeError) as e:
            self.send_bytes(400, json.dumps({"ok":False,"error":str(e)}).encode())
        except Exception as e:
            self.send_bytes(500, json.dumps({"ok":False,"error":f"Build server error: {e}"}).encode())
    def build(self, files, run_tests):
        temp = Path(tempfile.mkdtemp(prefix="hush-build-"))
        project = temp / "project"; project.mkdir()
        written = 0
        try:
            for entry in files:
                if not isinstance(entry, dict) or not isinstance(entry.get("path"), str) or not isinstance(entry.get("content"), str):
                    raise ValueError("Each file must contain string path and content fields.")
                raw = entry["path"].replace('\\', '/')
                rel = PurePosixPath(raw)
                if not raw or rel.is_absolute() or any(p in ("", ".", "..") for p in rel.parts) or re.match(r"^[A-Za-z]:", raw):
                    raise ValueError(f"Unsafe relative path: {raw!r}")
                content = entry["content"]
                written += len(content.encode("utf-8"))
                if written > MAX_BODY: raise ValueError("Combined source content exceeds 8 MiB.")
                dest = project.joinpath(*rel.parts); dest.parent.mkdir(parents=True, exist_ok=True); dest.write_text(content, encoding="utf-8")
            build_dir = temp / "build"
            commands = [["cmake", "-S", str(project), "-B", str(build_dir), "-DCMAKE_BUILD_TYPE=Release", "-DHUSH_BUILD_TESTS=ON"], ["cmake", "--build", str(build_dir), "--config", "Release", "--parallel", "2"]]
            logs = []
            for cmd in commands:
                p = subprocess.run(cmd, cwd=temp, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
                logs.append("$ " + " ".join(cmd) + "\n" + p.stdout)
                if p.returncode != 0:
                    return {"ok":False,"stage":"configure" if len(logs)==1 else "compile","returncode":p.returncode,"log":"\n\n".join(logs),"artifacts":[]}
            test_dir = build_dir
            if run_tests:
                p = subprocess.run(["ctest", "--test-dir", str(test_dir), "--output-on-failure", "-C", "Release"], cwd=temp, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
                logs.append("$ ctest --test-dir build --output-on-failure\n" + p.stdout)
                if p.returncode != 0:
                    # Keep build successful but explicitly mark test failure.
                    tests_ok = False
                else: tests_ok = True
            else: tests_ok = None
            outzip = temp / "HUSH-build-artifacts.zip"
            with zipfile.ZipFile(outzip, "w", zipfile.ZIP_DEFLATED) as z:
                for f in project.rglob("*"):
                    if f.is_file(): z.write(f, Path("source") / f.relative_to(project))
                for f in build_dir.rglob("*"):
                    if f.is_file() and (f.suffix in (".a", ".lib", ".so", ".dll", ".dylib", ".exe", ".pdb") or f.name in ("hush_bench", "hush_offline_render") or (os.name != "nt" and os.access(f, os.X_OK))):
                        z.write(f, Path("artifacts") / f.relative_to(build_dir))
                z.writestr("BUILD-REPORT.txt", "HUSH Build Studio report\nBuild: PASS\nTests: " + ("PASS" if tests_ok else "FAIL" if tests_ok is False else "NOT RUN") + "\nPlatform: " + os.name + "\n\n" + "\n\n".join(logs))
            return {"ok":True,"tests_ok":tests_ok,"log":"\n\n".join(logs),"zip_base64":__import__('base64').b64encode(outzip.read_bytes()).decode("ascii"),"zip_name":"HUSH-build-artifacts.zip","artifact_count":sum(1 for f in build_dir.rglob('*') if f.is_file() and (f.suffix in ('.a','.lib','.so','.dll','.dylib','.exe') or f.name in ('hush_bench','hush_offline_render') or (os.name != 'nt' and os.access(f, os.X_OK))))}
        except subprocess.TimeoutExpired as e:
            return {"ok":False,"stage":"timeout","error":"Build exceeded the 180-second command limit.","log":(e.stdout or b"").decode(errors="replace") if isinstance(e.stdout,bytes) else (e.stdout or ""),"artifacts":[]}
        finally:
            shutil.rmtree(temp, ignore_errors=True)

if __name__ == "__main__":
    print(f"HUSH Build Studio listening locally at http://{HOST}:{PORT}")
    print("This service binds to localhost only; do not expose it to a public network.")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
