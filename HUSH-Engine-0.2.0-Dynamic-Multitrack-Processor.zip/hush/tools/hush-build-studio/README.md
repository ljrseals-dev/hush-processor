# HUSH Build Studio — From Paste → Create Build

A local browser UI and Python standard-library server for pasting a CMake-based C++ project, building it with the machine's installed toolchain, running CTest, and downloading a ZIP containing the pasted source, native build artifacts, and a build report.

## Requirements

- Python 3.10+
- CMake 3.20+
- A working C++ compiler on `PATH` (MSVC developer environment on Windows, Xcode command-line tools on macOS, GCC/Clang on Linux)

## Run

**Linux/macOS**

```sh
python3 tools/hush-build-studio/server.py
```

**Windows**

```bat
py tools\hush-build-studio\server.py
```

Open <http://127.0.0.1:8765> in your browser. The server binds to localhost only. It does not upload source to a cloud service.

## From Paste format

Use a marker line for each file:

```text
--- FILE: CMakeLists.txt ---
cmake_minimum_required(VERSION 3.20)
project(Example LANGUAGES CXX)
add_executable(example main.cpp)

--- FILE: main.cpp ---
int main() { return 0; }
```

The **From Paste** button also lets you select source files from disk; the **Create Build** button configures and compiles the pasted file set, optionally runs CTest, and enables **Download Build ZIP** after completion. A root `CMakeLists.txt` is required. The helper rejects absolute paths and `..` traversal and limits requests to 8 MiB / 500 files. Builds have a 180-second per-command timeout.

## Security and limitations

- Intended for local development only. Do not bind it to `0.0.0.0` or expose it to an untrusted network; building arbitrary C++ is executing code.
- Build execution is performed by the local compiler and CMake. Compiler, generator, SDK, and platform errors are reported in the UI log.
- The source-only export button produces a portable text bundle; the build-artifacts ZIP is a real ZIP archive created by the local helper.
- A successful compile does not certify real-time safety, DSP correctness, or DAW-host compatibility.
