#include "hush/audio/engine.hpp"
#include <array>
#include <chrono>
#include <cstdio>
#include <vector>
int main() {
 constexpr std::size_t block=512U, blocks=300U;
 std::array<float,block> in{},left{},right{}; in.fill(0.0001F);
 for(const std::size_t count : {1U,8U,64U,256U,512U}) {
  hush::Engine engine; if(!engine.prepare({48000.0,static_cast<std::uint32_t>(block),2U})) return 1;
  for(std::size_t i=0;i<count;++i) if(engine.addTrack()==0U) return 2;
  std::vector<const float*> inputs(count*2U);
  for(std::size_t i=0;i<count;++i) { inputs[i*2U]=in.data(); inputs[i*2U+1U]=in.data(); }
  const auto start=std::chrono::steady_clock::now();
  for(std::size_t i=0;i<blocks;++i) engine.processAll(inputs.data(),left.data(),right.data(),block);
  const auto end=std::chrono::steady_clock::now();
  const double ns=std::chrono::duration<double,std::nano>(end-start).count()/static_cast<double>(blocks);
  std::printf("tracks=%zu block=%zu sample_rate=48000 avg=%.1f ns/block %.3f us/block %.3f ns/track-frame\n",count,block,ns,ns/1000.0,ns/(static_cast<double>(count)*static_cast<double>(block)));
 }
 return 0;
}
