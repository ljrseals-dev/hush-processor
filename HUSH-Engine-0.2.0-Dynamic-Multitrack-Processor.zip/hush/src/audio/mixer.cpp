#include "hush/audio/mixer.hpp"
#include "hush/core/denormals.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <new>
#include <stdexcept>
#include <utility>
namespace hush {
Mixer::Mixer() {
 auto initial = std::make_unique<Graph>();
 activeGraph_.store(initial.release(), std::memory_order_seq_cst);
}
Mixer::~Mixer() {
 // Destruction requires the host to have stopped audio callbacks.
 std::lock_guard<std::mutex> lock(controlMutex_);
 delete activeGraph_.exchange(nullptr, std::memory_order_seq_cst);
 retiredGraphs_.clear();
 tracks_.clear();
}
bool Mixer::prepare(AudioConfig c) noexcept {
 if(!validSampleRate(c.sampleRate)||!validBlockSize(c.maxBlockSize)||c.channels==0U||c.channels>kMaxChannels)return false;
 try {
  std::lock_guard<std::mutex> lock(controlMutex_);
  std::vector<float> left(c.maxBlockSize,0.0F), right(c.maxBlockSize,0.0F);
  for(auto& item:tracks_) item.second->prepare(c.sampleRate);
  master_.prepare(c.sampleRate);
  config_=c; scratchLeft_.swap(left); scratchRight_.swap(right);
  return true;
 } catch (...) { return false; }
}
bool Mixer::publishOrderLocked(const std::vector<TrackId>& order) {
 try {
  auto next=std::make_unique<Graph>();
  next->entries.reserve(order.size());
  for(const auto id:order) {
   const auto it=tracks_.find(id);
   if(it==tracks_.end()||!it->second) return false;
   next->entries.push_back({id,it->second.get()});
  }
  next->byId=next->entries;
  std::sort(next->byId.begin(),next->byId.end(),[](const Entry& a,const Entry& b){return a.id<b.id;});
  auto newOrder=order;
  retiredGraphs_.reserve(retiredGraphs_.size()+1U);
  const Graph* old=activeGraph_.exchange(next.release(),std::memory_order_seq_cst);
  if(old!=nullptr) retiredGraphs_.emplace_back(const_cast<Graph*>(old));
  order_.swap(newOrder);
  collectRetiredLocked();
  return true;
 } catch (...) { return false; }
}
void Mixer::collectRetiredLocked() noexcept {
 if(audioReaders_.load(std::memory_order_seq_cst)!=0U)return;
 retiredGraphs_.clear();
 for(auto it=tracks_.begin();it!=tracks_.end();) {
  if(std::find(order_.begin(),order_.end(),it->first)==order_.end()) it=tracks_.erase(it);
  else ++it;
 }
}
TrackId Mixer::addTrack() {
 std::lock_guard<std::mutex> lock(controlMutex_);
 if(nextTrackId_==0U||nextTrackId_==std::numeric_limits<TrackId>::max()) return 0U;
 const TrackId id=nextTrackId_++;
 try {
  auto t=std::make_unique<Track>();
  t->prepare(config_.sampleRate);
  tracks_.emplace(id,std::move(t));
  auto next=order_; next.push_back(id);
  if(!publishOrderLocked(next)) { tracks_.erase(id); return 0U; }
  return id;
 } catch (...) { tracks_.erase(id); return 0U; }
}
bool Mixer::removeTrack(TrackId id) {
 std::lock_guard<std::mutex> lock(controlMutex_);
 const auto found=std::find(order_.begin(),order_.end(),id);
 if(found==order_.end())return false;
 auto next=order_; next.erase(next.begin()+std::distance(order_.begin(),found));
 return publishOrderLocked(next);
}
bool Mixer::moveTrack(TrackId id,std::size_t newIndex) {
 std::lock_guard<std::mutex> lock(controlMutex_);
 const auto found=std::find(order_.begin(),order_.end(),id);
 if(found==order_.end()||newIndex>=order_.size())return false;
 auto next=order_; next.erase(next.begin()+std::distance(order_.begin(),found));
 next.insert(next.begin()+static_cast<std::ptrdiff_t>(newIndex),id);
 return publishOrderLocked(next);
}
void Mixer::collectRetired() noexcept { try { std::lock_guard<std::mutex> lock(controlMutex_); collectRetiredLocked(); } catch (...) {} }
std::size_t Mixer::trackCount() const noexcept { std::lock_guard<std::mutex> lock(controlMutex_); return order_.size(); }
TrackId Mixer::trackIdAt(std::size_t index) const {
 std::lock_guard<std::mutex> lock(controlMutex_);
 if(index>=order_.size())throw std::out_of_range("HUSH track index out of range");
 return order_[index];
}
Track& Mixer::track(std::size_t index) {
 std::lock_guard<std::mutex> lock(controlMutex_);
 if(index>=order_.size())throw std::out_of_range("HUSH track index out of range");
 return *tracks_.at(order_[index]);
}
Track* Mixer::findTrack(TrackId id) noexcept {
 std::lock_guard<std::mutex> lock(controlMutex_); const auto it=tracks_.find(id); return it==tracks_.end()?nullptr:it->second.get();
}
const Track* Mixer::findTrack(TrackId id) const noexcept {
 std::lock_guard<std::mutex> lock(controlMutex_); const auto it=tracks_.find(id); return it==tracks_.end()?nullptr:it->second.get();
}
void Mixer::applyCommands(const Graph& graph) noexcept {
 Command c{};
 while(commands_.pop(c)) {
  const auto found=std::lower_bound(graph.byId.begin(),graph.byId.end(),c.track,[](const Entry& entry,TrackId id){return entry.id<id;});
  if(found==graph.byId.end()||found->id!=c.track) { rejectedCommands_.fetch_add(1U,std::memory_order_relaxed); continue; }
  Track* target=found->track;
  switch(c.type) {
   case CommandType::SetGain: target->setGain(c.value); break;
   case CommandType::SetPan: target->setPan(c.value); break;
   case CommandType::SetMute: target->setMute(c.value>=0.5F); break;
   case CommandType::SetSolo: target->setSolo(c.value>=0.5F); break;
   case CommandType::SetPhase: target->setPhaseInvert(c.value>=0.5F); break;
   case CommandType::SetBypass: target->setBypass(c.value>=0.5F); break;
  }
 }
}
void Mixer::process(const float* const* inputs,float* outL,float* outR,std::size_t n,std::size_t active) noexcept { processGraph(inputs,outL,outR,n,active); }
void Mixer::processAll(const float* const* inputs,float* outL,float* outR,std::size_t n) noexcept { processGraph(inputs,outL,outR,n,std::numeric_limits<std::size_t>::max()); }
void Mixer::processGraph(const float* const* inputs,float* outL,float* outR,std::size_t n,std::size_t active) noexcept {
 if(outL==nullptr||outR==nullptr)return;
 if(n>config_.maxBlockSize||scratchLeft_.size()<n||scratchRight_.size()<n) { std::fill_n(outL,n,0.0F); std::fill_n(outR,n,0.0F); return; }
 audioReaders_.fetch_add(1U,std::memory_order_seq_cst);
 const Graph* graph=activeGraph_.load(std::memory_order_seq_cst);
 if(graph==nullptr) { std::fill_n(outL,n,0.0F); std::fill_n(outR,n,0.0F); audioReaders_.fetch_sub(1U,std::memory_order_seq_cst); return; }
 {
  ScopedDenormals denormals; (void)denormals;
  applyCommands(*graph);
  std::fill_n(outL,n,0.0F); std::fill_n(outR,n,0.0F);
  const std::size_t count=std::min(active,graph->entries.size());
  bool anySolo=false;
  for(std::size_t i=0U;i<count;++i) anySolo=anySolo||graph->entries[i].track->soloed();
  for(std::size_t t=0U;t<count;++t) {
   const float* inL=inputs!=nullptr?inputs[t*2U]:nullptr;
   const float* inR=inputs!=nullptr?inputs[t*2U+1U]:nullptr;
   auto& left=scratchLeft_; auto& right=scratchRight_;
   graph->entries[t].track->process(inL,inR,left.data(),right.data(),n,anySolo);
   for(std::size_t i=0U;i<n;++i) { outL[i]+=left[i]; outR[i]+=right[i]; }
  }
  master_.process(outL,outR,n);
 }
 audioReaders_.fetch_sub(1U,std::memory_order_seq_cst);
}
}
