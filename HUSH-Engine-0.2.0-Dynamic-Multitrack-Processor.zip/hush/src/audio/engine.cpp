#include "hush/audio/engine.hpp"
namespace hush {
// The public engine API is intentionally thin; ownership and synchronization live in Mixer.
static_assert(sizeof(TrackId) >= sizeof(std::uint64_t));
}
