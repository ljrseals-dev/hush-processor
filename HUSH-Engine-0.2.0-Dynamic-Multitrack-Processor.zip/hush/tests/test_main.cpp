#include "hush/audio/engine.hpp"
#include "hush/control/command_queue.hpp"
#include "hush/dsp/simper_svf.hpp"
#include "hush/dsp/sparsity_declip.hpp"
#include "hush/simd/ops.hpp"
#include <array>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <limits>
#include <thread>
#include <vector>
namespace {
int failures=0; int checks=0;
#define CHECK(expr) do { ++checks; if(!(expr)) { std::fprintf(stderr,"FAIL %s:%d: %s\n",__FILE__,__LINE__,#expr); ++failures; } } while(false)
void testQueue() { hush::SpscQueue<int,4U> q; CHECK(q.push(1));CHECK(q.push(2));CHECK(q.push(3));CHECK(!q.push(4));int v=0;CHECK(q.pop(v)&&v==1);CHECK(q.pop(v)&&v==2); }
void testSVF() { hush::SimperSVF f;f.prepare(48000.0);CHECK(f.setParameters(1000.0,0.7071067811865476));const double g=std::tan(3.14159265358979323846*1000.0/48000.0),k=1.0/0.7071067811865476,a1=1.0/(1.0+g*(g+k));CHECK(std::abs(f.coefficientA1()-a1)<1.0e-12);CHECK(std::abs(f.coefficientA2()-g*a1)<1.0e-12);CHECK(std::abs(f.coefficientA3()-g*g*a1)<1.0e-12); }
void testSimd() { std::array<float,9> in{},out{};in[0]=1.0F;in[8]=std::numeric_limits<float>::infinity();hush::simd::scalarApplyGain(out.data(),in.data(),out.size(),0.5F);CHECK(std::abs(out[0]-0.5F)<1.0e-6F);CHECK(out[8]==0.0F); }
void testDeclip() { hush::SparsityDeclipper d;CHECK(d.prepare(8U));std::array<float,8>x{0,1,1,0,0,-1,-1,0},y{};std::array<unsigned char,8> m{0,1,1,0,0,1,1,0};CHECK(d.process(x.data(),m.data(),y.data(),x.size()));CHECK(y[0]==x[0]);CHECK(y[3]==x[3]); }
void testDynamicTracks() {
 hush::Engine e; CHECK(e.prepare({48000.0,128U,2U})); CHECK(!e.prepare({12345.0,128U,2U})); CHECK(e.prepare({48000.0,128U,2U}));
 constexpr std::size_t count=512U, frames=128U; std::vector<hush::TrackId> ids; ids.reserve(count);
 for(std::size_t i=0;i<count;++i) { auto id=e.addTrack(); CHECK(id!=0U); ids.push_back(id); }
 CHECK(e.trackCount()==count); CHECK(e.mixer().trackIdAt(511U)==ids[511U]); CHECK(e.mixer().moveTrack(ids[511U],0U)); CHECK(e.mixer().trackIdAt(0U)==ids[511U]);
 std::array<float,frames> input{},left{},right{}; input.fill(0.0001F); std::vector<const float*> ptrs(count*2U); for(std::size_t i=0;i<count;++i){ptrs[i*2U]=input.data();ptrs[i*2U+1U]=input.data();}
 e.processAll(ptrs.data(),left.data(),right.data(),frames); CHECK(std::isfinite(left[64])); CHECK(left[64]>0.001F); CHECK(left[64]<=1.0F);
 for(std::size_t i=0;i<128U;++i) { CHECK(e.removeTrack(ids[i])); }
 CHECK(e.trackCount()==384U); CHECK(e.mixer().findTrack(ids[0])==nullptr); CHECK(e.mixer().findTrack(ids[128])!=nullptr);
 }
void testConcurrentGraphPublication() {
 hush::Engine e; CHECK(e.prepare({48000.0,64U,2U})); for(int i=0;i<8;++i) CHECK(e.addTrack()!=0U);
 std::array<float,64> in{},l{},r{}; in.fill(0.001F); std::vector<const float*> ptrs(1200U,in.data());
 std::atomic<bool> start{false}; std::thread audio([&]{while(!start.load(std::memory_order_acquire)){} for(int i=0;i<1500;++i)e.processAll(ptrs.data(),l.data(),r.data(),64U);});
 start.store(true,std::memory_order_release);
 for(int i=0;i<100;++i) { auto id=e.addTrack(); CHECK(id!=0U); if(e.trackCount()>12U) { const auto removeId=e.mixer().trackIdAt(0U); CHECK(e.removeTrack(removeId)); } }
 audio.join(); CHECK(e.trackCount()>=8U); for(float v:l) CHECK(std::isfinite(v));
 }
}
int main() {
 testQueue(); testSVF(); testSimd(); testDeclip(); testDynamicTracks(); testConcurrentGraphPublication();
 if(failures!=0) { std::fprintf(stderr,"HUSH tests: %d failure(s)\n",failures); return 1; }
 std::printf("HUSH tests: %d checks passed\n",checks); return 0;
}
