# Changelog

## 0.2.0 — Dynamic Multitrack Processor Core

- Removed the fixed 64-track storage ceiling; tracks now use stable 64-bit IDs and dynamically managed control-plane storage.
- Added immutable graph snapshots, safe publication to the single audio reader, deferred reclamation, and an explicit maintenance-thread `collectRetired()` method.
- Replaced per-track stack scratch arrays with prepared shared stereo scratch buffers.
- Changed queued control commands to address stable track IDs and added a stale/unknown-command counter.
- Added dynamic 512-track functional coverage, concurrent graph-publication stress coverage, sanitizer test configurations, and a scaling benchmark for 1–512 tracks.
- Removed the external doctest fetch requirement from the default test build.
- Updated the validation report to distinguish verified local behavior from platform/host work still unverified or not implemented.
