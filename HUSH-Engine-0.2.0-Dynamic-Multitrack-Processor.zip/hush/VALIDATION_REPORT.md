# HUSH Engine 0.2.0 — Validation Report

Date: 2026-10-14

## Summary

**Status: BUILD-VERIFIED / NOT RELEASE-CERTIFIED.** The Linux GCC 14.2 Release build, functional/stress test executable, ASan+UBSan test run, and ThreadSanitizer test run passed in this environment. This is meaningful implementation evidence, not certification for a real-time DAW or audio-device deployment.

## Build and test evidence

- **PASS:** GCC 14.2, Linux x86-64, CMake Release configure/build with tests, benchmarks, and example enabled.
- **PASS:** CTest — `1/1` test executable passed. The executable performs dependency-free assertions covering queue behavior, SVF coefficients, SIMD scalar sanitization, declipper behavior, 512-track summing/ID stability/reorder/removal, and concurrent graph publication during processing.
- **PASS:** AddressSanitizer + UndefinedBehaviorSanitizer Debug build and CTest, with leak detection enabled.
- **PASS:** ThreadSanitizer Debug build and CTest, including the concurrent graph-publication stress test.
- **PASS:** Offline-render example: `Offline render completed; peak 0.2000`.
- **PASS:** Scaling benchmark executed on this environment. 48 kHz, 512-frame block, 300 blocks per track count. Results are local measurements, not portable performance guarantees.

### Measured mixer benchmark

| Tracks | Average time per 512-frame block | Average time per track-frame |
|---:|---:|---:|
| 1 | 7.483 µs | 14.616 ns |
| 8 | 15.829 µs | 3.865 ns |
| 64 | 75.120 µs | 2.292 ns |
| 256 | 288.691 µs | 2.203 ns |
| 512 | 574.355 µs | 2.191 ns |

The benchmark was run in a shared container; CPU model, isolated-core scheduling, thermal state, and target-device callback jitter were not controlled. Use results for rough scaling inspection only.

## Implemented

- C++20 static library and CMake 3.20+ project.
- Dynamic track creation/removal without a fixed 64-track array limit; stable 64-bit IDs.
- Track reordering while preserving IDs.
- Immutable processing graph snapshots built on the control path and atomically published.
- Reader-count-based deferred graph/track reclamation for the documented single-audio-reader model.
- Preallocated shared stereo scratch buffers; no per-track stack scratch arrays.
- Bounded SPSC command queue using stable track IDs and a rejected-command counter.
- Track gain smoothing, pan, mute, solo, phase inversion, bypass, master bus, limiter, and metering.
- Scalar/SSE2/AVX2/NEON gain kernels, Simper SVF, variable-cadence helper, subband FIR primitive, declipper, denormal handling.
- Offline render example, dependency-free tests, concurrent graph-publication stress case, and multi-size track-count benchmark.
- HUSH Build Studio local paste/import-to-CMake-build helper.

## Constraints and unverified areas

- **NOT VERIFIED:** Windows/MSVC and macOS/Clang builds; CI workflow is present but has not been run on those platforms in this environment.
- **NOT VERIFIED:** ASIO, WASAPI, CoreAudio, ALSA/JACK device callbacks, DAW-host integration, glitch-free device reconfiguration, or plugin hosting.
- **NOT IMPLEMENTED:** Full routing graph with aux sends/subgroups, feedback routing, track automation lanes, instrument/plugin hosting, transport, file decoder, and versioned session serialization.
- **NOT IMPLEMENTED:** Runtime CPU-feature dispatch; SIMD kernel selection is compile-time based. Do not run an AVX2 build on a CPU that lacks AVX2 support.
- **NOT IMPLEMENTED:** Oversampled true-peak limiting. Current limiter/clamp is sample-level and does not guarantee inter-sample true-peak compliance.
- **NOT IMPLEMENTED:** Complete MPEG polyphase analysis/synthesis filter bank or full STFT-domain declipping solver; related modules are explicitly DSP primitives.
- **CONSTRAINT:** The graph-reclamation design is for a single audio callback reader. Stop audio callbacks before `prepare()` or object destruction. Do not retain `Track*`/`Track&` obtained from control accessors across concurrent track removal.
- **CONSTRAINT:** Control-thread graph creation can fail due to allocation failure; add/move/remove report failure rather than promising unbounded capacity. Practical track count is limited by memory and callback budget.
- **NOT VERIFIED:** Long-duration soak testing, hard-real-time scheduling, allocation-hook instrumentation inside the callback, golden audio render comparisons, and subjective listening evaluation.

## Release gate

The package is **not release-certified**. Passing sanitizers and stress tests does not prove hard-real-time deadline safety, all-platform correctness, or host compatibility. Those require target-machine, device, and host validation.
