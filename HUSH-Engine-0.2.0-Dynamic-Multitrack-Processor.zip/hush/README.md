# HUSH Engine — Dynamic Multitrack Processor Core

**HUSH Engine** is a C++20 real-time audio-processing foundation with a dynamically sized multitrack mixer, stable track identities, prepared immutable processing-graph snapshots, bounded SPSC command transport, DSP primitives, and repeatable local validation.

> **Capacity statement:** HUSH has no fixed 64-track ceiling. Track capacity is limited by memory, routing/processing work, and the target machine's callback deadline. This core does not claim infinite processing capacity or DAW-host certification.

## Features implemented in this build

- Dynamically created and removed tracks; 64-bit stable `TrackId` values.
- Track reordering without changing track identity.
- Audio-thread graph snapshots published from the control thread; retired graph/track storage is reclaimed on a control-thread path after audio readers have left.
- Shared preallocated stereo scratch buffers; no per-track stack arrays and no intentional heap allocation in the processing loop.
- Track gain smoothing, pan, mute, solo, phase inversion, bypass, master gain/mute, and master limiting/metering.
- Bounded SPSC command queue; commands target stable track IDs. Unknown/stale IDs are counted by `rejectedCommands()`.
- Scalar/SSE2/AVX2/NEON gain kernels, Simper SVF, variable-cadence helper, subband FIR primitive, sparsity declipper, denormal handling, offline example, stress tests, and scaling benchmark.
- Local **HUSH Build Studio** at `tools/hush-build-studio/` for importing pasted CMake project files and building locally.

## Build and validate

Requires CMake 3.20+ and a C++20 compiler. Tests use an in-repository dependency-free harness, so configuring and testing does not require fetching doctest.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
  -DHUSH_BUILD_TESTS=ON -DHUSH_BUILD_BENCHMARKS=ON -DHUSH_BUILD_EXAMPLES=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
./build/benchmarks/hush_bench
./build/examples/hush_offline_render
```

The test suite checks queue FIFO/full behavior, Simper coefficients, scalar-kernel sanitization, declipper sample preservation, dynamic creation and summing at 512 tracks, stable IDs/reordering/removal, and concurrent graph publication while processing.

## Minimal API example

```cpp
#include "hush/audio/engine.hpp"
#include <array>

int main() {
 hush::Engine engine;
 if (!engine.prepare({48000.0, 128U, 2U})) return 1;
std::array<float, 128> vocalBuffer{}, musicBuffer{}, outputLeft{}, outputRight{};
const float* vocalLeft = vocalBuffer.data();
const float* vocalRight = vocalBuffer.data();
const float* musicLeft = musicBuffer.data();
const float* musicRight = musicBuffer.data();
const hush::TrackId vocal = engine.addTrack();
const hush::TrackId music = engine.addTrack();
if (vocal == 0U || music == 0U) return 2;
engine.mixer().findTrack(vocal)->setGain(0.8F);
engine.mixer().findTrack(music)->setPan(-0.15F);

// Inputs are stereo pointer pairs in current visual track order:
// [track 0 L, track 0 R, track 1 L, track 1 R, ...].
const float* inputs[4]{vocalLeft, vocalRight, musicLeft, musicRight};
engine.processAll(inputs, outputLeft.data(), outputRight.data(), outputLeft.size());
 engine.mixer().collectRetired();
 return 0;
}
```

`TrackId` is the durable identity; visual index is only ordering. `Mixer::track(index)`, `trackIdAt`, and `findTrack` are control-plane accessors. Do not retain a returned `Track*`/`Track&` across concurrent removal. Serialize control operations at the application level when multiple control clients need coordinated edits.

## Threading contract and limitations

- `processAll`/`process` is designed for one audio callback thread. Graphs are immutable after publication. The callback does not take the control mutex or allocate per track.
- Graph construction, track allocation, graph publication, and reclamation run on control threads. **Stop audio callbacks before `prepare` or destruction.**
- The SPSC queue requires exactly one producer and one consumer. Its bounded capacity is independent of track count; queue-full enqueue returns `false` and the caller must handle that result.
- Graph swaps are lifetime-safe for the documented single-audio-reader model; this is not a multi-audio-callback graph-reader design. Call `Mixer::collectRetired()` periodically from a maintenance/control thread to reclaim snapshots after a graph edit that overlapped an active callback.
- The current core is a stereo summing processor, not a complete DAW routing graph. It does not yet implement aux sends, subgroup routing, automation lanes, instrument/plugin hosting, transport, device backends, session serialization, or feedback routing.
- `process(inputs, ..., activeTracks)` processes a prefix of the current visual track order. `processAll` processes every active track in the published graph.
- The current limiter uses sample-level limiting/clamping; it is **not** a verified oversampled true-peak limiter. SIMD selection remains compile-time based, not runtime CPUID dispatch.
- The subband and declipping modules remain focused DSP primitives rather than complete MPEG polyphase and STFT-domain research implementations.

## HUSH Build Studio — From Paste → Create Build

Run `python3 tools/hush-build-studio/server.py` (Windows: `py tools\\hush-build-studio\\server.py`) and open `http://127.0.0.1:8765`. The helper binds to localhost and uses the local compiler/CMake. Building arbitrary pasted C++ executes code; use only trusted projects. See its README for details.

## Validation status

Linux GCC 14.2 Release build and CTest are run for this archive; see [`VALIDATION_REPORT.md`](VALIDATION_REPORT.md) for measured results and explicit unverified items. Windows/macOS builds, sanitizers, real audio-device callbacks, DAW-host integration, and release certification are not claimed.

## License

No license is declared in this package. Choose and add a license before public redistribution.
