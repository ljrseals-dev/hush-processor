#pragma once
#include <cstdint>
namespace hush {
enum class CommandType : std::uint8_t { SetGain, SetPan, SetMute, SetSolo, SetPhase, SetBypass };
// `track` is a stable TrackId, not a visual track index.
struct Command { CommandType type{CommandType::SetGain}; std::uint64_t track{0U}; float value{0.0F}; };
}
