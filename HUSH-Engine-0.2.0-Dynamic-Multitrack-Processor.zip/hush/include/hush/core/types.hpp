#pragma once
#include <cstddef>
#include <cstdint>
namespace hush {
using Sample = float;
// There is intentionally no fixed maximum track count. These constants bound other resources.
constexpr std::size_t kMaxChannels = 8U;
constexpr std::size_t kCommandCapacity = 256U;
struct AudioConfig { double sampleRate{48000.0}; std::uint32_t maxBlockSize{512U}; std::uint32_t channels{2U}; };
struct Stereo { float left{0.0F}; float right{0.0F}; };
struct Meter { float peak{0.0F}; float rms{0.0F}; };
inline bool validSampleRate(double sr) noexcept { return sr == 44100.0 || sr == 48000.0 || sr == 88200.0 || sr == 96000.0 || sr == 176400.0 || sr == 192000.0; }
inline bool validBlockSize(std::uint32_t n) noexcept { return n == 32U || n == 64U || n == 128U || n == 256U || n == 512U || n == 1024U || n == 2048U; }
}
