#pragma once
#include "hush/audio/track.hpp"
#include "hush/audio/master_bus.hpp"
#include "hush/control/command.hpp"
#include "hush/control/command_queue.hpp"
#include "hush/core/types.hpp"
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <vector>
namespace hush {
using TrackId = std::uint64_t;

// Dynamically sized mixer. All track/graph mutations are control-thread operations;
// process() is the single audio-thread entry point. Graphs are immutable after publish.
class Mixer final {
public:
 Mixer();
 ~Mixer();
 Mixer(const Mixer&) = delete;
 Mixer& operator=(const Mixer&) = delete;
 bool prepare(AudioConfig config) noexcept;
 bool enqueue(const Command& command) noexcept { return commands_.push(command); }
 TrackId addTrack();
 bool removeTrack(TrackId id);
 bool moveTrack(TrackId id, std::size_t newIndex);
 // Call periodically from a control/maintenance thread to reclaim retired graphs after callbacks finish.
 void collectRetired() noexcept;
 std::size_t trackCount() const noexcept;
 TrackId trackIdAt(std::size_t index) const;
 Track& track(std::size_t index);
 Track* findTrack(TrackId id) noexcept;
 const Track* findTrack(TrackId id) const noexcept;
 MasterBus& master() noexcept { return master_; }
 const MasterBus& master() const noexcept { return master_; }
 // Legacy-compatible prefix processing: processes min(activeTracks, current track count).
 void process(const float* const* inputs,float* outL,float* outR,std::size_t frames,std::size_t activeTracks) noexcept;
 void processAll(const float* const* inputs,float* outL,float* outR,std::size_t frames) noexcept;
 std::uint64_t rejectedCommands() const noexcept { return rejectedCommands_.load(std::memory_order_relaxed); }
private:
 struct Entry { TrackId id{}; Track* track{}; };
 struct Graph { std::vector<Entry> entries; std::vector<Entry> byId; };
 AudioConfig config_{};
 std::unordered_map<TrackId,std::unique_ptr<Track>> tracks_;
 std::vector<TrackId> order_;
 mutable std::mutex controlMutex_;
 std::atomic<const Graph*> activeGraph_{nullptr};
 std::atomic<std::uint32_t> audioReaders_{0U};
 std::vector<std::unique_ptr<Graph>> retiredGraphs_;
 std::vector<float> scratchLeft_, scratchRight_;
 SpscQueue<Command,kCommandCapacity> commands_{};
 MasterBus master_{};
 TrackId nextTrackId_{1U};
 std::atomic<std::uint64_t> rejectedCommands_{0U};
 bool publishOrderLocked(const std::vector<TrackId>& order);
 void collectRetiredLocked() noexcept;
 void applyCommands(const Graph& graph) noexcept;
 void processGraph(const float* const* inputs,float* outL,float* outR,std::size_t frames,std::size_t activeTracks) noexcept;
};
}
