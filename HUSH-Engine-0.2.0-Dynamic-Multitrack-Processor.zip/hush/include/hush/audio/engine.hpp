#pragma once
#include "hush/audio/mixer.hpp"
namespace hush {
class Engine final {
public:
 bool prepare(AudioConfig config) noexcept { return mixer_.prepare(config); }
 TrackId addTrack() { return mixer_.addTrack(); }
 bool removeTrack(TrackId id) { return mixer_.removeTrack(id); }
 bool moveTrack(TrackId id,std::size_t newIndex) { return mixer_.moveTrack(id,newIndex); }
 std::size_t trackCount() const noexcept { return mixer_.trackCount(); }
 Mixer& mixer() noexcept { return mixer_; }
 const Mixer& mixer() const noexcept { return mixer_; }
 void process(const float* const* inputs,float* left,float* right,std::size_t frames,std::size_t activeTracks) noexcept { mixer_.process(inputs,left,right,frames,activeTracks); }
 void processAll(const float* const* inputs,float* left,float* right,std::size_t frames) noexcept { mixer_.processAll(inputs,left,right,frames); }
private:
 Mixer mixer_{};
};
}
