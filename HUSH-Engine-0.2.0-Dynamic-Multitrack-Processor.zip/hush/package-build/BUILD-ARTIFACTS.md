# HUSH Engine 0.2.0 Build Artifacts

Included prebuilt Linux x86-64 artifacts built from the included 0.2.0 source:
- `linux-x86_64/libhush.a` — static HUSH Engine library
- `linux-x86_64/hush_offline_render` — offline-render example executable
- `linux-x86_64/hush_bench` — track-count scaling benchmark executable
- `linux-x86_64/hush_tests` — dependency-free functional and stress test executable

Validation performed in the Linux GCC 14.2 environment is documented in `VALIDATION_REPORT.md`. These are Linux binaries, not Windows or macOS builds. Reconfigure and rebuild from source for each target platform. This package does not claim DAW-host or audio-device certification.
