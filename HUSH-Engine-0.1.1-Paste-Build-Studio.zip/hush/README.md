# HUSH Engine

**HUSH** is an original C++20 real-time audio-engine foundation focused on bounded callback work, explicit thread boundaries, portable DSP, and reproducible validation.

## Architecture

```mermaid
flowchart LR
  UI[UI / Automation] --> Q[SPSC Command Queue]
  Q --> E[Audio Engine]
  E --> T[Track Mixer]
  T --> K[SIMD Kernel Dispatch]
  T --> D[DSP Modules]
  K --> M[Master Bus]
  D --> M
  M --> O[Output Buffers]
  W[Non-RT Restoration Work] -. prepared results .-> Q
```

## Build

```sh
cmake -S . -B build -DHUSH_BUILD_TESTS=ON -DHUSH_BUILD_BENCHMARKS=ON
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
./build/benchmarks/hush_bench
```

The unit tests use doctest fetched through CMake FetchContent. A first test-enabled configure therefore needs network access unless the dependency is already cached. For an offline compile of the library only, configure with `-DHUSH_BUILD_TESTS=OFF -DHUSH_BUILD_BENCHMARKS=OFF -DHUSH_BUILD_EXAMPLES=OFF`.

## Thread and memory model

- `Mixer::process` is intended for the audio thread. It consumes a bounded number of fixed-size commands, uses fixed-capacity track storage, and rejects blocks larger than the prepared maximum.
- `SpscQueue<T, 256>` requires exactly one producer and one consumer. It is not an MPMC queue.
- Track and master scalar controls use relaxed atomics. The command queue uses acquire/release publication.
- DSP scratch storage for the current mixer is stack-bounded by the supported maximum block size. Restoration buffers allocate in `prepare`, not in `process`.
- Device adapters are intentionally not part of the core. Host/backend integration must own device lifecycle, callback setup, and teardown outside the callback.

## Modules

| Module | Implementation notes |
|---|---|
| SIMD | Scalar kernel plus SSE2, AVX2, and NEON gain kernels; compile-time ISA availability selects the kernel table. Non-vector tails are handled. |
| Simper SVF | Uses `g = tan(pi * fc / fs)`, `k = 1/Q`, `a1 = 1/(1 + g*(g+k))`, `a2 = g*a1`, `a3 = g*a2`, with double-precision state and six selectable output modes. |
| Variable cadence | Callback-based cadence helper that batches stable regions in groups of four and switches to single-sample updates when its envelope-change threshold is crossed. |
| Subband filter | Per-band FIR processing and history at the supplied subband rate. It is a filtering primitive, not a complete MPEG polyphase analysis/synthesis bank. |
| Sparsity declipper | Iterative soft-thresholded second-difference reconstruction for samples marked clipped. It is a lightweight sparse prior, not a reproduction of a specific paper's full time-frequency solver. |
| Limiter | Feed-forward envelope detection, smoothed gain, tanh soft-knee region, and sample clamp. |

## Current status and limitations

This package is an implementation baseline, not a release-certified DAW engine. The tests are executable assertions but have not been run on all three CI operating systems in this environment. The current SIMD dispatch is based on compile-time ISA macros, not runtime CPUID detection; build-specific AVX2 binaries must only be run on compatible CPUs. SIMD kernels currently accelerate gain application; stereo accumulation remains scalar. The subband module does not include MPEG filter-bank analysis/synthesis or alias-cancellation proof. The declipper is not a full STFT-domain sparsity solver and needs objective audio restoration benchmarks and listening tests. The variable-cadence helper is not yet integrated into a dynamic EQ coefficient path. There is no device backend, plugin host, transport clock, graph mutation system, or true-peak oversampling stage.

The prompt's cited performance values are research-reported figures and are not claimed as HUSH benchmark results. Run the benchmark on target hardware and report measured results. A sample clamp does not ensure inter-sample true-peak compliance.

## CI and AWS CodeConnections

The included GitHub Actions workflow configures, builds, and tests Windows, macOS, and Linux. To connect a repository through AWS CodeConnections, create/authorize a connection in AWS Developer Tools, grant access to the selected GitHub or GitLab repository, then configure CodeBuild or CodePipeline to use that connection. Keep credentials in the CI provider's secret store; do not place tokens in this repository.

## API sketch

```cpp
hush::Engine engine;
if (!engine.prepare({48000.0, 128U, 2U})) return;
hush::Command c{hush::CommandType::SetGain, 0U, 0.8F};
engine.mixer().enqueue(c);
const float* inputs[2]{leftInput, rightInput};
engine.process(inputs, leftOutput, rightOutput, 128U, 1U);
```

## License

No license is declared in this generated package. Choose and add a license before public redistribution.

## HUSH Build Studio — From Paste → Create Build

A local browser-based build helper is included at `tools/hush-build-studio/`. Start it with `python3 tools/hush-build-studio/server.py` (Windows: `py tools\hush-build-studio\server.py`) and open `http://127.0.0.1:8765`. Use **From Paste** to import marked-up files from the clipboard, **Import Files** to select local source files, and **Create Build** to run CMake, compile, optionally run CTest, and download a build-artifacts ZIP. See `tools/hush-build-studio/README.md` for requirements and security notes.
